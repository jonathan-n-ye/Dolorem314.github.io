/*
    Name: Raquel Canto and Jonathan Ye
    Date: November 8th, 2023
    Teacher: Ms. Krasteva
    Assignment #12
    Raquel worked on this class.
*/
import java.awt.*;
import hsa.Console; //import Console class
import java.lang.*;     // to access Thread class

public class DragonIn extends Thread
{
    //Declaration of Colors
    Color brightYellow = new Color (250, 255, 40);
    Color brownYellow = new Color (156, 121, 17); //broom straw
    Color lightBrown = new Color (181, 153, 94); //broomstick
    Color royalPurple = new Color (103, 78, 167); //witch dress, broom bearing
    Color mediumGreen = new Color (106, 168, 79); //witch skin
    Color darkGrey = new Color (67, 67, 67);    //witch hat + dress
    Color nightSky = new Color (0, 51, 102); //color for night sky
    Color darkGreen = new Color (39, 78, 19);

    private Console c;

    public void animation ()
    {
	for (int i = -100 ; i <= 260 ; i++)
	{
	    dragon (i);
	    delay (i);
	    eraseTrail (i);
	}
	c.setColor (darkGreen);
	c.fillRect (0, 400, 430, 40);


    }


    public void dragon (int x)
    {
	//x+260 y+230
	//DRAGON TORSO AND HEAD
	c.setColor (Color.RED);
	int dragonX[] = {5 + x, 10 + x, 20 + x, 30 + x, 40 + x, 50 + x, 60 + x, 70 + x, 80 + x, 90 + x, 100 + x, 110 + x, 115 + x, 120 + x, 105 + x, 105 + x, 120 + x, 120 + x, 115 + x, 110 + x, 100 + x, 90 + x, 80 + x, 70 + x, 60 + x, 50 + x, 40 + x, 30 + x, 20 + x, 10 + x, 10 + x};
	int dragonY[] = {30 + 230, 35 + 230, 25 + 230, 35 + 230, 25 + 230, 35 + 230, 25 + 230, 35 + 230, 25 + 230, 35 + 230, 25 + 230, 30 + 230, 30 + 230, 25 + 230, 25 + 230, 17 + 230, 17 + 230, 15 + 230, 15 + 230, 10 + 230, 10 + 230, 20 + 230, 10 + 230, 20 + 230, 10 + 230, 20 + 230, 10 + 230, 20 + 230, 10 + 230, 20 + 230, 25 + 230};
	c.fillPolygon (dragonX, dragonY, 31); //dragon body
	//DRAGON LEGS
	c.setColor (Color.RED);
	int rightLegX[] = {80 + x, 80 + x, 85 + x, 90 + x, 90 + x, 85 + x};
	int rightLegY[] = {30 + 230, 35 + 230, 35 + 230, 30 + 230, 25 + 230, 25 + 230};
	c.fillPolygon (rightLegX, rightLegY, 6); //right leg
	int leftLegX[] = {40 + x, 40 + x, 45 + x, 50 + x, 50 + x, 45 + x};
	int leftLegY[] = {30 + 230, 35 + 230, 35 + 230, 30 + 230, 25 + 230, 25 + 230};
	c.fillPolygon (leftLegX, leftLegY, 6); //left leg
	c.setColor (brightYellow);
	c.fillRect (80 + x, 35 + 230, 5, 10);
	c.fillRect (75 + x, 40 + 230, 5, 5);
	c.fillRect (40 + x, 35 + 230, 5, 10);
	c.fillRect (35 + x, 40 + 230, 5, 5);
	//DRAGON FACIAL FEAUTURES
	int headX[] = {85 + x, 85 + x, 92 + x, 95 + x, 100 + x, 100 + x, 95 + x, 92 + x};
	int headY[] = {0 + 230, 5 + 230, 12 + 230, 10 + 230, 15 + 230, 10 + 230, 5 + 230, 7 + 230};
	c.fillPolygon (headX, headY, 8);
	c.setColor (Color.WHITE);
	c.fillOval (102 + x, 12 + 230, 6, 6); //eye
	c.setColor (Color.BLACK);
	c.fillOval (104 + x, 14 + 230, 2, 2); //pupil
	c.drawLine (110 + x, 5 + 230, 118 + x, 15 + 230);
	//Teeth
	c.setColor (Color.WHITE);
	int bottomTeethX[] = {110 + x, 120 + x, 120 + x, 115 + x, 112 + x};
	int bottomTeethY[] = {25 + 230, 25 + 230, 20 + 230, 25 + 230, 20 + 230};
	c.fillPolygon (bottomTeethX, bottomTeethY, 5);
	int topTeethX[] = {115 + x, 120 + x, 120 + x};
	int topTeethY[] = {17 + 230, 17 + 230, 20 + 230};
	c.fillPolygon (topTeethX, topTeethY, 3);
	//DRAGON SPIKES
	c.setColor (brightYellow);
	int bottomSpikeX[] = {5 + x, 5 + x, 10 + x};
	int bottomSpikeY[] = {30 + 230, 35 + 230, 35 + 230};
	c.fillPolygon (bottomSpikeX, bottomSpikeY, 3);
	int firstSpikeX[] = {15 + x, 20 + x, 15 + x};
	int firstSpikeY[] = {10 + 230, 10 + 230, 15 + 230};
	c.fillPolygon (firstSpikeX, firstSpikeY, 3);
	int secondSpikeX[] = {35 + x, 40 + x, 35 + x};
	int secondSpikeY[] = {10 + 230, 10 + 230, 15 + 230};
	c.fillPolygon (secondSpikeX, secondSpikeY, 3);
	int thirdSpikeX[] = {55 + x, 60 + x, 55 + x};
	int thirdSpikeY[] = {10 + 230, 10 + 230, 15 + 230};
	c.fillPolygon (thirdSpikeX, thirdSpikeY, 3);
	int fourthSpikeX[] = {75 + x, 80 + x, 75 + x};
	int fourthSpikeY[] = {10 + 230, 10 + 230, 15 + 230};
	c.fillPolygon (fourthSpikeX, fourthSpikeY, 3);
    }


    public void delay (int x)
    {
	try
	{
	    Thread.sleep (10);
	}
	catch (Exception e)
	{
	}
    }


    public void eraseTrail (int x)
    {
	int dragonX[] = {5 + x, 10 + x, 20 + x, 30 + x, 40 + x, 50 + x, 60 + x, 70 + x, 80 + x, 90 + x, 100 + x, 110 + x, 115 + x, 120 + x, 105 + x, 105 + x, 120 + x, 120 + x, 115 + x, 110 + x, 100 + x, 90 + x, 80 + x, 70 + x, 60 + x, 50 + x, 40 + x, 30 + x, 20 + x, 10 + x, 10 + x};
	int dragonY[] = {30 + 230, 35 + 230, 25 + 230, 35 + 230, 25 + 230, 35 + 230, 25 + 230, 35 + 230, 25 + 230, 35 + 230, 25 + 230, 30 + 230, 30 + 230, 25 + 230, 25 + 230, 17 + 230, 17 + 230, 15 + 230, 15 + 230, 10 + 230, 10 + 230, 20 + 230, 10 + 230, 20 + 230, 10 + 230, 20 + 230, 10 + 230, 20 + 230, 10 + 230, 20 + 230, 25 + 230};
	int rightLegX[] = {80 + x, 80 + x, 85 + x, 90 + x, 90 + x, 85 + x};
	int rightLegY[] = {30 + 230, 35 + 230, 35 + 230, 30 + 230, 25 + 230, 25 + 230};
	int leftLegX[] = {40 + x, 40 + x, 45 + x, 50 + x, 50 + x, 45 + x};
	int leftLegY[] = {30 + 230, 35 + 230, 35 + 230, 30 + 230, 25 + 230, 25 + 230};
	int headX[] = {85 + x, 85 + x, 92 + x, 95 + x, 100 + x, 100 + x, 95 + x, 92 + x};
	int headY[] = {0 + 230, 5 + 230, 12 + 230, 10 + 230, 15 + 230, 10 + 230, 5 + 230, 7 + 230};
	int bottomTeethX[] = {110 + x, 120 + x, 120 + x, 115 + x, 112 + x};
	int bottomTeethY[] = {25 + 230, 25 + 230, 20 + 230, 25 + 230, 20 + 230};
	int topTeethX[] = {115 + x, 120 + x, 120 + x};
	int topTeethY[] = {17 + 230, 17 + 230, 20 + 230};
	int bottomSpikeX[] = {5 + x, 5 + x, 10 + x};
	int bottomSpikeY[] = {30 + 230, 35 + 230, 35 + 230};
	int firstSpikeX[] = {15 + x, 20 + x, 15 + x};
	int firstSpikeY[] = {10 + 230, 10 + 230, 15 + 230};
	int secondSpikeX[] = {35 + x, 40 + x, 35 + x};
	int secondSpikeY[] = {10 + 230, 10 + 230, 15 + 230};
	int thirdSpikeX[] = {55 + x, 60 + x, 55 + x};
	int thirdSpikeY[] = {10 + 230, 10 + 230, 15 + 230};
	int fourthSpikeX[] = {75 + x, 80 + x, 75 + x};
	int fourthSpikeY[] = {10 + 230, 10 + 230, 15 + 230};
	if (x != 260)
	{
	    c.setColor (nightSky);
	    c.fillPolygon (dragonX, dragonY, 31); //dragon body
	    c.fillPolygon (rightLegX, rightLegY, 6); //right leg
	    c.fillPolygon (leftLegX, leftLegY, 6); //left leg
	    c.fillRect (80 + x, 35 + 230, 5, 10);
	    c.fillRect (75 + x, 40 + 230, 5, 5);
	    c.fillRect (40 + x, 35 + 230, 5, 10);
	    c.fillRect (35 + x, 40 + 230, 5, 5);
	    c.fillPolygon (headX, headY, 8);
	    c.drawLine (110 + x, 5 + 230, 118 + x, 15 + 230);
	    c.fillPolygon (bottomTeethX, bottomTeethY, 5);
	    c.fillPolygon (topTeethX, topTeethY, 3);
	    c.fillPolygon (bottomSpikeX, bottomSpikeY, 3);
	    c.fillPolygon (firstSpikeX, firstSpikeY, 3);
	    c.fillPolygon (secondSpikeX, secondSpikeY, 3);
	    c.fillPolygon (thirdSpikeX, thirdSpikeY, 3);
	    c.fillPolygon (fourthSpikeX, fourthSpikeY, 3);
	}
    }



    public DragonIn (Console con)  //constructor
    {
	c = con;
    }


    public void run ()
    {
	animation ();
    }
}




