/*
   Name: Raquel Canto and Jonathan Ye
   Teacher: Ms. Krasteva
   Date: November 9, 2023
   Jonathan and Raquel worked on this class.


*/
import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class UFODown extends Thread
{
    Color gold = new Color (217, 182, 61);
    Color brightOrange = new Color (255, 165, 30);
    Color royalPurple = new Color (103, 78, 167);
    Color mediumGreen = new Color (106, 168, 79);
    Color mediumGrey = new Color (153, 153, 153);
    Color nightSky = new Color (0, 51, 102); //color for night sky
    Color lightYellow = new Color (255, 242, 204);
    Color darkGreen = new Color (39, 78, 19);
    private Console c;

    public void ufoDown ()
    {
	//Down
	for (int i = 200 ; i > 0 ; i--)
	{
	    drawUFO (i);
	    delay ();
	    eraseTrail (i);
	}

    }


    public void text ()
    {
	c.setFont (new Font ("Courier", 1, 13));
	c.setColor (Color.WHITE);
	c.drawString ("Long: What is that? It's a UFO!", 10, 415);
    }


    public void eraseText ()
    {
	c.setColor (darkGreen);
	c.fillRect (0, 400, 430, 40);
    }


    public UFODown (Console con)
    {
	c = con;
    }


    public void delay ()
    {
	try
	{
	    Thread.sleep (30);
	}
	catch (Exception e)
	{
	}
    }


    public void drawUFO (int y)
    {
	//Ufo body
	c.setColor (royalPurple);
	c.fillOval (320 - 140, 100 - 60 - y, 280, 120);
	c.setColor (mediumGrey);
	c.fillOval (320 - 140, 80 - 60 - y, 280, 120);
	c.setColor (mediumGreen);
	c.fillArc (320 - 80, 80 - 80 - y, 160, 160, 0, 180);
	c.fillArc (320 - 80, 80 - 20 - y, 160, 40, 180, 180);

	//Ufo dots
	c.setColor (gold);
	c.fillOval (220 - 10, 60 - 10 - y, 20, 20);
	c.fillOval (200 - 10, 80 - 10 - y, 20, 20);
	c.fillOval (220 - 10, 100 - 10 - y, 20, 20);
	c.fillOval (420 - 10, 60 - 10 - y, 20, 20);
	c.fillOval (440 - 10, 80 - 10 - y, 20, 20);
	c.fillOval (420 - 10, 100 - 10 - y, 20, 20);

	//Ufo class part
	c.setColor (brightOrange);
	c.fillOval (300 - 8, 150 - 8 - y, 16, 16);
	c.fillOval (320 - 8, 150 - 8 - y, 16, 16);
	c.fillOval (340 - 8, 150 - 8 - y, 16, 16);

	//Ufo star
	c.fillStar (320 - 15, 115 - 15 - y, 30, 30);
    }


    public void eraseTrail (int y)
    {
	//Draws nightsky background
	c.setColor (nightSky);
	c.drawArc (320 - 140, 80 - 60 - y - 1, 280, 120, 0, 180);
	c.fillOval (320 - 80, 80 - 80 - y - 1, 160, 160);

    }


    public void run ()
    {
	text ();
	ufoDown ();
	eraseText ();
    }
}
