/*
   Name: Raquel Canto and Jonathan Ye
   Teacher: Ms. Krasteva
   Date: November 9, 2023
   This class is NOT a Thread - There are no moving objects
   Jonathan and Raquel worked on this class.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Introduction
{
    //global variable used to a
    private Console c;

    //class to make background
    public void introduction ()
    {
	Color nightSky = new Color (0, 51, 102);

	c.setColor (Color.WHITE);
	c.setFont (new Font ("Monotype Corsiva", 1, 40));
	c.drawString ("Halloween Night", 45, 300);
	c.setFont (new Font ("Monotype Corsiva", 0, 20));
	c.drawString ("Press any key to continue:", 45, 330);
	c.getChar ();
	c.setColor (nightSky);
	c.fillRect (45, 270, 280, 70);
    }


    public Introduction (Console con)
    {
	c = con;
	introduction ();
    }
}




