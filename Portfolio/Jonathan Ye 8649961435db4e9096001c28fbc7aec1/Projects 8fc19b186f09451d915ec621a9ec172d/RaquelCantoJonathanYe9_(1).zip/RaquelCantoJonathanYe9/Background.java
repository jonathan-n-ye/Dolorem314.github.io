/*
   Name: Raquel Canto and Jonathan Ye
   Teacher: Ms. Krasteva
   Date: November 9, 2023
   This class is NOT a Thread - There are no moving objects
   Jonathan and Raquel worked on this class.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Background
{
    private Console c;
    //Declaration of colors
    Color nightSky = new Color (0, 51, 102); //colour for night sky
    Color lightGrey = new Color (183, 183, 183); //colour for clouds
    Color darkGreen = new Color (39, 78, 19); //colour for grass and pumpkin stem
    Color mediumGrey = new Color (153, 153, 153); //colour for sidewalk
    Color mediumDarkGrey = new Color (102, 102, 102); //colour for path next to driveway
    Color darkGrey = new Color (67, 67, 67); //colour for driveway
    Color lightYellow = new Color (255, 242, 204); //colour for moon
    Color darkBrown = new Color (120, 63, 4); //colour for  tree
    Color darkOrange = new Color (180, 95, 6); //colour for roof
    Color darkRed = new Color (102, 0, 0); //colour for door
    Color gold = new Color (217, 182, 61); //colour for doorknobs
    Color middleOrange = new Color (200, 100, 0); //colour for punpkin

    //class to make background
    public void sky ()
    {
	//loop to color sky
	c.setColor (nightSky);
	for (int y = 0 ; y < 640 ; y++)
	{
	    c.drawLine (0, y, 640, y);
	}
    }


    public void grass ()
    {
	//loop to color grass
	for (int x = 0 ; x <= 640 ; x++)
	{

	    c.setColor (darkGreen);
	    c.drawRect (0, 400, x, 100);
	}
    }


    public void driveway ()
    {
	//loop to draw driveway
	c.setColor (darkGrey);
	for (int x = 520 ; x <= 600 ; x++)
	{
	    c.drawRect (x, 400, x, 500);
	}

	//loops to draw borders
	c.setColor (mediumDarkGrey);
	for (int x = 520 ; x <= 540 ; x++) //left border
	{
	    c.drawLine (x, 400, x - 20, 500);
	}
	for (int x = 580 ; x <= 600 ; x++) //right border
	{
	    c.drawLine (x, 400, x + 20, 500);
	}
    }


    public void sidewalk ()
    {
	//loop to draw sidewalk
	c.setColor (mediumGrey);
	for (int x = 0 ; x <= 640 ; x++)
	{
	    c.drawRect (0, 440, x, 40);
	}
	//loop to draw sidewalk cracks
	c.setColor (mediumDarkGrey);
	for (int x = 0 ; x <= 640 ; x += 60)
	{
	    c.drawLine (x, 440, x, 480);
	}
    }


    public void moon ()
    {
	//loop to draw moon
	c.setColor (lightYellow);
	customFillCircle (320, 120, 100);
    }


    public void clouds ()
    {
	//Clouds
	c.setColor (lightGrey);
	//loops to draw clouds
	customFillCircle (60, 60, 20);
	customFillCircle (90, 50, 20);
	customFillCircle (120, 70, 20);
	customFillCircle (150, 60, 20);
	customFillCircle (210, 210, 20);
	customFillCircle (240, 200, 20);
	customFillCircle (270, 200, 20);
	customFillCircle (300, 200, 20);
	customFillCircle (360, 200, 20);
	customFillCircle (390, 210, 20);
	customFillCircle (420, 200, 20);
	customFillCircle (450, 190, 20);
	customFillCircle (480, 140, 20);
	customFillCircle (510, 150, 20);
	customFillCircle (540, 140, 20);
	customFillCircle (570, 130, 20);
	customFillCircle (540, 60, 20);
	customFillCircle (570, 60, 20);
	customFillCircle (600, 60, 20);
	customFillCircle (60, 160, 20);
	customFillCircle (90, 150, 20);
	customFillCircle (120, 170, 20);
    }


    public void house ()
    {
	//loop to draw house (also dark brown)
	c.setColor (darkBrown);
	for (int x = 480 ; x <= 640 ; x++)
	{
	    c.drawRect (x, 320, 0, 80);
	}
	//loops to draw roof
	c.setColor (darkOrange);
	for (int x = 440 ; x < 440 + 12 * 20 ; x++)
	{
	    c.drawLine (560, 250, x, 320);
	}
    }


    public void doors ()
    {
	//loops to draw doors
	c.setColor (darkRed);
	for (int x = 540 ; x <= 580 ; x++)
	{
	    c.drawRect (x, 360, 0, 40); //doors
	}
	c.setColor (Color.black);
	for (int x = 540 ; x <= 580 ; x += 20)
	{
	    c.drawLine (x, 360, x, 400); //door edges
	}
	c.setColor (darkRed);
	customFillCircle (560, 360, 19, true, true); //arc above door

	c.setColor (Color.BLACK);
	c.drawArc (560 - 20, 360 - 20, 40, 40, 0, 180); //edge around arc
	c.drawLine (540, 360, 580, 360); //edge between arc and door

	//draw door knobs
	c.setColor (gold);
	customFillCircle (555, 380, 2); //left knob
	customFillCircle (565, 380, 2); //right knob
    }


    public void windows ()
    {
	//loops to draw windows
	c.setColor (Color.BLACK);
	for (int i = 495 ; i < 525 ; i++)
	{
	    c.drawLine (i, 335, i, 385);
	}

	for (int i = 495 + 5 * 20 ; i < 525 + 5 * 20 ; i++)
	{
	    c.drawLine (i, 335, i, 385);
	}

	c.setColor (mediumDarkGrey);
	for (int i = 500 ; i < 508 ; i++)
	{
	    c.drawLine (i, 340, i, 360);
	}

	for (int i = 513 ; i < 520 ; i++)
	{
	    c.drawLine (i, 340, i, 360);
	}

	for (int i = 500 ; i < 508 ; i++)
	{
	    c.drawLine (i, 365, i, 380);
	}

	for (int i = 513 ; i < 520 ; i++)
	{
	    c.drawLine (i, 365, i, 380);
	}

	for (int i = 500 + 100 ; i < 508 + 100 ; i++)
	{
	    c.drawLine (i, 340, i, 360);
	}

	for (int i = 513 + 100 ; i < 520 + 100 ; i++)
	{
	    c.drawLine (i, 340, i, 360);
	}

	for (int i = 500 + 100 ; i < 508 + 100 ; i++)
	{
	    c.drawLine (i, 365, i, 380);
	}

	for (int i = 513 + 100 ; i < 520 + 100 ; i++)
	{
	    c.drawLine (i, 365, i, 380);
	}
    }


    public void tree ()
    {
	//loops to draw tree
	c.setColor (darkBrown);
	for (int x = 425 ; x < 460 ; x++)
	{
	    c.drawLine (400, 260, x, 400);
	}
	for (int x = 420 ; x < 440 ; x++)
	{
	    c.drawLine (460, 260, x, 360);
	}
	for (int x = 445 ; x < 450 ; x++)
	{
	    c.drawLine (440, 250, x, 300);
	}
	for (int x = 445 ; x < 450 ; x++)
	{
	    c.drawLine (440, 250, x, 300);
	}
	for (int x = 405 ; x < 415 ; x++)
	{
	    c.drawLine (370, 260, x, 300);
	}
	for (int x = 415 ; x < 430 ; x++)
	{
	    c.drawLine (430, 230, x, 340);
	}
	for (int x = 425 ; x < 432 ; x++)
	{
	    c.drawLine (400, 200, x, 280);
	}
    }


    public void pumpkins ()
    {
	//jack-o-lanterns
	c.setColor (darkGreen);
	for (int x = 455 ; x <= 465 ; x++)
	{
	    c.drawLine (470, 360, x, 385);
	}
	c.setColor (darkOrange);
	customFillOval (155 + 290, 400, 20, 40);
	customFillOval (185 + 290, 400, 20, 40);
	c.setColor (middleOrange);
	customFillOval (460, 400, 30, 40);
	c.setColor (Color.BLACK);
	for (int i = 0 ; i < 20 ; i++)
	{
	    c.drawLine (i + 150 + 290, 400, 160 + 290, 390);
	}
	for (int i = 0 ; i < 20 ; i++)
	{
	    c.drawLine (i + 170 + 290, 400, 180 + 290, 390);
	}
	customFillCircle (170 + 290, 405, 10, true);
    }


    public void names ()
    {
	//draw our names
	c.setColor (Color.WHITE);
	c.setFont (new Font ("Dubai", Font.BOLD, 10));
	c.drawString ("Program By: Raquel Canto and Jonathan Ye", 5, 495);
    }


    private void customFillCircle (int x, int y, int r)
    {
	for (int i = -r ; i <= r ; i++)
	{
	    c.drawLine ((int) Math.pow (Math.pow (r, 2) - Math.pow (i, 2), 0.5) + x, i + y, (int) - Math.pow (Math.pow (r, 2) - Math.pow (i, 2), 0.5) + x, i + y);
	}
    }


    private void customFillCircle (int x, int y, int r, boolean isHalf)
    {
	for (int i = 0 ; i <= r ; i++)
	{
	    c.drawLine ((int) Math.pow (Math.pow (r, 2) - Math.pow (i, 2), 0.5) + x, i + y, (int) - Math.pow (Math.pow (r, 2) - Math.pow (i, 2), 0.5) + x, i + y);
	}
    }


    private void customFillCircle (int x, int y, int r, boolean isHalf, boolean topHalf)
    {
	for (int i = -r ; i <= 0 ; i++)
	{
	    c.drawLine ((int) Math.pow (Math.pow (r, 2) - Math.pow (i, 2), 0.5) + x, i + y, (int) - Math.pow (Math.pow (r, 2) - Math.pow (i, 2), 0.5) + x, i + y);
	}
    }


    private void customFillOval (int x, int y, int r1, int r2)
    {
	for (int i = 0 ; i <= r1 ; i += 1)
	{
	    c.drawOval (x + i / 2 - r1 / 2, y - r2 / 2, r1 - i, r2);
	}
    }


    public Background (Console con)
    {
	c = con;
	sky ();
	grass ();
	driveway ();
	sidewalk ();
	moon ();
	clouds ();
	house ();
	doors ();
	windows ();
	tree ();
	pumpkins ();
	names ();
    }
}




