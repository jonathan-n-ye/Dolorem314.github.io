/*
   Name: Raquel Canto and Jonathan Ye
   Teacher: Ms. Krasteva
   Date: November 9, 2023
   Jonathan worked on this class.

*/
import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class UFOUp extends Thread
{
    Color gold = new Color (217, 182, 61);
    Color brightOrange = new Color (255, 165, 30);
    Color royalPurple = new Color (103, 78, 167);
    Color mediumGreen = new Color (106, 168, 79);
    Color mediumGrey = new Color (153, 153, 153);
    Color nightSky = new Color (0, 51, 102);
    Color lightYellow = new Color (255, 242, 204);
    private Console c;

    public void ufoUp ()
    {
	for (int i = 0 ; i < 200 ; i++)
	{

	    drawUFO (i);
	    delay ();
	    eraseTrail (i);
	}

    }


    public void delay ()
    {
	try
	{
	    Thread.sleep (30);
	}
	catch (Exception e)
	{
	}
    }


    public void drawUFO (int y)
    {
	//Ufo body
	c.setColor (royalPurple);
	c.fillOval (320 - 140, 100 - 60 - y, 280, 120);
	c.setColor (mediumGrey);
	c.fillOval (320 - 140, 80 - 60 - y, 280, 120);
	c.setColor (mediumGreen);
	c.fillArc (320 - 80, 80 - 80 - y, 160, 160, 0, 180);
	c.fillArc (320 - 80, 80 - 20 - y, 160, 40, 180, 180);

	//Ufo dots
	c.setColor (gold);
	c.fillOval (220 - 10, 60 - 10 - y, 20, 20);
	c.fillOval (200 - 10, 80 - 10 - y, 20, 20);
	c.fillOval (220 - 10, 100 - 10 - y, 20, 20);
	c.fillOval (420 - 10, 60 - 10 - y, 20, 20);
	c.fillOval (440 - 10, 80 - 10 - y, 20, 20);
	c.fillOval (420 - 10, 100 - 10 - y, 20, 20);

	//Ufo class part
	c.setColor (brightOrange);
	c.fillOval (300 - 8, 150 - 8 - y, 16, 16);
	c.fillOval (320 - 8, 150 - 8 - y, 16, 16);
	c.fillOval (340 - 8, 150 - 8 - y, 16, 16);

	//Ufo star
	c.fillStar (320 - 15, 115 - 15 - y, 30, 30);
    }


    public void eraseTrail (int y)
    {
	//Draws nightsky background
	c.setColor (nightSky);
	c.fillOval (320 - 140, 100 - 60 - y + 1, 280, 120);
	c.setColor (lightYellow);

	//Draws moon background
	int moonX = 320;
	int moonY = 120;
	int r = 100;
	int y1 = 20 - y + moonY;
	int y2 = 40 - y + moonY;
	for (int i = y1 - moonY ; i <= y2 - moonY ; i++)
	{
	    if (Math.abs (((int) Math.pow (Math.pow (r, 2) - Math.pow (i, 2), 0.5) + moonX) - ((int) - Math.pow (Math.pow (r, 2) - Math.pow (i, 2), 0.5) + moonX)) > 5)
	    {
		c.drawLine ((int) Math.pow (Math.pow (r, 2) - Math.pow (i, 2), 0.5) + moonX, i + moonY, (int) - Math.pow (Math.pow (r, 2) - Math.pow (i, 2), 0.5) + moonX, i + moonY);
	    }
	}
    }



    public UFOUp (Console con)
    {
	c = con;
    }


    public void run ()
    {
	ufoUp ();
    }
}
