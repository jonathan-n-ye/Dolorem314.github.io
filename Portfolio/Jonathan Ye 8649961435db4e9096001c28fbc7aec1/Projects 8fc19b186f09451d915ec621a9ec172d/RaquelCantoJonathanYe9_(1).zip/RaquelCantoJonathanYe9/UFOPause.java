/*
   Name: Raquel Canto and Jonathan Ye
   Teacher: Ms. Krasteva
   Date: November 9, 2023
   Jonathan worked on this class.


*/
import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class UFOPause extends Thread
{
    Color gold = new Color (217, 182, 61);
    Color brightOrange = new Color (255, 165, 30);
    Color royalPurple = new Color (103, 78, 167);
    Color mediumGreen = new Color (106, 168, 79);
    Color mediumGrey = new Color (153, 153, 153);
    Color nightSky = new Color (0, 51, 102); //color for night sky
    Color lightYellow = new Color (255, 242, 204);
    private Console c;

    public void ufoPause ()
    {

	drawUFO ();
	pause ();
	Background b = new Background (c);

    }


    public void drawUFO ()
    {
	c.setColor (brightOrange);
	int[] lightX = { - 450, 1090, 320};
	int[] lightY = {500, 500, 100};
	c.fillPolygon (lightX, lightY, 3);

	int y = 0;
	
	//Ufo body
	c.setColor (royalPurple);
	c.fillOval (320 - 140, 100 - 60 - y, 280, 120);
	c.setColor (mediumGrey);
	c.fillOval (320 - 140, 80 - 60 - y, 280, 120);
	c.setColor (mediumGreen);
	c.fillArc (320 - 80, 80 - 80 - y, 160, 160, 0, 180);
	c.fillArc (320 - 80, 80 - 20 - y, 160, 40, 180, 180);
	
	//Ufo dots
	c.setColor (gold);
	c.fillOval (220 - 10, 60 - 10 - y, 20, 20);
	c.fillOval (200 - 10, 80 - 10 - y, 20, 20);
	c.fillOval (220 - 10, 100 - 10 - y, 20, 20);
	c.fillOval (420 - 10, 60 - 10 - y, 20, 20);
	c.fillOval (440 - 10, 80 - 10 - y, 20, 20);
	c.fillOval (420 - 10, 100 - 10 - y, 20, 20);
	
	//Ufo class part
	c.setColor (brightOrange);
	c.fillOval (300 - 8, 150 - 8 - y, 16, 16);
	c.fillOval (320 - 8, 150 - 8 - y, 16, 16);
	c.fillOval (340 - 8, 150 - 8 - y, 16, 16);
	
	//Ufo star
	c.fillStar (320 - 15, 115 - 15 - y, 30, 30);
    }


    public void pause ()
    {
	try
	{
	    Thread.sleep (3000);
	}
	catch (Exception e)
	{
	}
    }


    public UFOPause (Console con)
    {
	c = con;
    }


    public void run ()
    {
	ufoPause ();
    }
}
