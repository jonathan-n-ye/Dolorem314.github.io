/*
Name: Raquel Canto and Jonathan Ye
Date: November 8th, 2023
Teacher: Ms. Krasteva
Assignment #12
Raquel worked on this class.
*/
import java.awt.*;
import hsa.Console; //import Console class
import java.lang.*;     // to access Thread class

public class FairyIn extends Thread
{
    Color gold = new Color (217, 182, 61); //crown and wand
    Color royalPurple = new Color (103, 78, 167); //crown jewel
    Color lightBrown = new Color (181, 153, 94); //hair
    Color lightPink = new Color (229, 138, 182); //dress
    Color darkPink = new Color (193, 60, 120);
    Color skinTone = new Color (245, 224, 216); //skin
    Color nightSky = new Color (0, 51, 102); //color for night sky
    Color darkGreen = new Color (39, 78, 19);

    private Console c; // c is variable representation of Console

    public void animation ()
    {

	c.setColor (darkGreen);
	c.fillRect (0, 400, 430, 40);

	c.setFont (new Font ("Courier", 1, 13));
	c.setColor (Color.WHITE);
	c.drawString ("Fairy: Halt right there, wicked witch! I won't let  ", 10, 415);
	c.drawString ("you harm these innocent creatures. Get her, Long!", 10, 430);

	//x+240 y+275
	for (int i = -50 ; i <= 50 ; i++)
	{
	    fairy (i);
	    delay ();
	    eraseTrail (i);
	}

    }


    public void fairy (int x)
    {
	//FAIRY
	c.setColor (lightBrown);
	c.fillRect (42 + x, 30 + 275, 35, 30); //hair
	c.setColor (skinTone);
	c.fillRect (55 + x, 45 + 275, 10, 10); //neck
	c.fillOval (45 + x, 25 + 275, 30, 30); //face
	c.fillRoundRect (50 + x, 80 + 275, 10, 40, 45, 45); //left leg
	c.fillRoundRect (60 + x, 80 + 275, 10, 40, 45, 45); //right leg
	c.setColor (lightBrown);
	c.fillArc (42 + x, 20 + 275, 35, 35, 0, 180);  //hair
	//DRESS
	c.setColor (lightPink);
	int emmaDressX[] = {50 + x, 55 + x, 65 + x, 70 + x, 80 + x, 70 + x, 80 + x, 40 + x, 50 + x, 50 + x, 40 + x, 30 + x, 30 + x, 40 + x}; //list of all x-coordinates for dress
	int emmaDressY[] = {55 + 275, 60 + 275, 60 + 275, 55 + 275, 70 + 275, 80 + 275, 100 + 275, 100 + 275, 80 + 275, 70 + 275, 80 + 275, 60 + 275, 50 + 275, 70 + 275}; // list of all y-coordinates for dress
	c.fillPolygon (emmaDressX, emmaDressY, 14);
	c.setColor (darkPink);
	c.drawLine (70 + x, 65 + 275, 70 + x, 80 + 275); //arm
	c.fillRect (50 + x, 75 + 275, 20, 5); //belt
	c.setColor (skinTone);
	c.fillArc (55 + x, 50 + 275, 10, 10, 0, -180); //neck
	//CROWN
	c.setColor (darkPink);
	c.fillRect (25 + x, 30 + 275, 5, 30); //wand stick
	c.setColor (gold);
	c.fillStar (15 + x, 15 + 275, 25, 25); //star for wand
	int emmaCrownX[] = {40 + x, 40 + x, 50 + x, 55 + x, 60 + x, 65 + x, 70 + x, 80 + x, 80 + x};
	int emmaCrownY[] = {25 + 275, 10 + 275, 20 + 275, 10 + 275, 20 + 275, 10 + 275, 20 + 275, 10 + 275, 25 + 275};
	c.fillPolygon (emmaCrownX, emmaCrownY, 9); //crown
	c.fillArc (40 + x, 15 + 275, 40, 17, 0, -180); //crown
	//CROWN JEWELS
	c.setColor (royalPurple);
	c.fillOval (35 + x, 5 + 275, 10, 10);
	c.fillOval (62 + x, 5 + 275, 10, 10);
	c.setColor (darkPink);
	c.fillOval (48 + x, 5 + 275, 10, 10);
	c.fillOval (75 + x, 5 + 275, 10, 10);
    }


    public void delay ()
    {
	try
	{
	    Thread.sleep (10);
	}
	catch (Exception e)
	{
	}
    }


    public void eraseTrail (int x)
    {
	int emmaDressX[] = {50 + x, 55 + x, 65 + x, 70 + x, 80 + x, 70 + x, 80 + x, 40 + x, 50 + x, 50 + x, 40 + x, 30 + x, 30 + x, 40 + x}; //list of all x-coordinates for dress
	int emmaDressY[] = {55 + 275, 60 + 275, 60 + 275, 55 + 275, 70 + 275, 80 + 275, 100 + 275, 100 + 275, 80 + 275, 70 + 275, 80 + 275, 60 + 275, 50 + 275, 70 + 275}; // list of all y-coordinates for dress
	int emmaCrownX[] = {40 + x, 40 + x, 50 + x, 55 + x, 60 + x, 65 + x, 70 + x, 80 + x, 80 + x};
	int emmaCrownY[] = {25 + 275, 10 + 275, 20 + 275, 10 + 275, 20 + 275, 10 + 275, 20 + 275, 10 + 275, 25 + 275};
	if (x != 50)
	{
	    c.setColor (nightSky);
	    c.fillRect (42 + x, 30 + 275, 35, 30); //hair
	    c.fillRect (55 + x, 45 + 275, 10, 10); //neck
	    c.fillRoundRect (50 + x, 80 + 275, 10, 40, 45, 45); //left leg
	    c.fillRoundRect (60 + x, 80 + 275, 10, 40, 45, 45); //right leg
	    c.fillArc (42 + x, 20 + 275, 35, 35, 0, 180);  //hair
	    c.fillPolygon (emmaDressX, emmaDressY, 14);
	    c.fillRect (25 + x, 30 + 275, 5, 30); //wand stick
	    c.fillStar (15 + x, 15 + 275, 25, 25); //star for wand
	    c.fillPolygon (emmaCrownX, emmaCrownY, 9); //crown
	    c.fillArc (40, 15 + 275, 40, 17, 0, -180); //crown
	    c.fillArc (55 + x, 50 + 275, 10, 10, 0, -180); //neck
	    //CROWN JEWELS
	    c.fillOval (35 + x, 5 + 275, 10, 10);
	    c.fillOval (62 + x, 5 + 275, 10, 10);
	    c.fillOval (48 + x, 5 + 275, 10, 10);
	    c.fillOval (75 + x, 5 + 275, 10, 10);
	}
    }


    public FairyIn (Console con)  //constructor
    {
	c = con;
    }


    public void run ()
    {
	animation ();
    }
}






