/*
   Name: Raquel Canto and Jonathan Ye
   Teacher: Ms. Krasteva
   Date: November 9, 2023
   Raquel and Jonathan worked on this class.

    This class is has 3 overloaded constructors!!!
    The basic constructor creates a bat in a specific predetermined location.
    The 2nd constructor allows a parameter pass to change the bat color.
    The 3rd constructor creates a bat with a specific color and a time delay to
    control the speed of its movement during the animation.

*/
import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class BatIn extends Thread
{
    private Console c;
    private Color batColor;
    Color nightSky = new Color (0, 51, 102);
    private int delay;
    private int tempX;
    private int y;

    public void animation ()
    {
	for (int a = tempX + 270 ; tempX < a ; tempX++)
	{
	    bat (tempX);
	    delay ();
	    eraseTrail (tempX);
	}
	bat (tempX);
    }


    public void bat (int x)
    {

	//body
	c.setColor (batColor);
	c.fillRect (15 + x, 10 + y, 30, 5);
	int earX[] = {20 + x, 20 + x, 25 + x, 35 + x, 40 + x, 40 + x, 35 + x, 25 + x};
	int earY[] = {0 + y, 5 + y, 10 + y, 10 + y, 5 + y, 0 + y, 5 + y, 5 + y};
	c.setColor (batColor);

	c.fillPolygon (earX, earY, 8);
	int wingX[] = {0 + x, 25 + x, 40 + x, 60 + x, 50 + x, 47 + x, 40 + x, 35 + x, 35 + x, 32 + x, 30 + x, 28 + x, 25 + x, 25 + x, 20 + x, 13 + x, 10 + x};
	int wingY[] = {0 + y, 10 + y, 10 + y, 0 + y, 10 + y, 15 + y, 20 + y, 30 + y, 20 + y, 25 + y, 20 + y, 25 + y, 20 + y, 30 + y, 20 + y, 15 + y, 10 + y};
	c.setColor (batColor);

	c.fillPolygon (wingX, wingY, 16);
	//eyes
	c.setColor (Color.WHITE);
	c.fillRoundRect (25 + x, 7 + y, 5, 6, 45, 45);
	c.setColor (Color.WHITE);

	c.fillRoundRect (30 + x, 7 + y, 5, 6, 45, 45);
	c.setColor (Color.BLACK);
	c.fillOval (27 + x, 9 + y, 2, 2);
	c.setColor (Color.BLACK);

	c.fillOval (32 + x, 9 + y, 2, 2);
    }


    public void delay ()
    {
	try
	{
	    sleep (delay);
	}


	catch (Exception e)
	{
	}
    }


    public void eraseTrail (int x)
    {

	int earX[] = {20 + x, 20 + x, 25 + x, 35 + x, 40 + x, 40 + x, 35 + x, 25 + x};
	int earY[] = {0 + y, 5 + y, 10 + y, 10 + y, 5 + y, 0 + y, 5 + y, 5 + y};
	int wingX[] = {0 + x, 25 + x, 40 + x, 60 + x, 50 + x, 47 + x, 40 + x, 35 + x, 35 + x, 32 + x, 30 + x, 28 + x, 25 + x, 25 + x, 20 + x, 13 + x, 10 + x};
	int wingY[] = {0 + y, 10 + y, 10 + y, 0 + y, 10 + y, 15 + y, 20 + y, 30 + y, 20 + y, 25 + y, 20 + y, 25 + y, 20 + y, 30 + y, 20 + y, 15 + y, 10 + y};
	c.setColor (nightSky);
	c.drawPolygon (earX, earY, 8);
	c.setColor (nightSky);
	c.drawPolygon (wingX, wingY, 16);

    }


    //basic bat
    public BatIn (Console con, int sX, int sY)
    {
	c = con;
	batColor = new Color (183, 183, 183);
	tempX = sX;
	y = sY;
	delay = 20;
    }


    // bat with a Color parameter
    public BatIn (Console con, int sX, int sY, Color n, int d)
    {
	c = con;
	batColor = n;
	delay = d;
	tempX = sX;
	y = sY;
    }


    // bat with a Color parameter, and a new delay time
    public BatIn (Console con, int sX, int sY, Color n)
    {
	c = con;
	batColor = n;
	delay = 20;
	tempX = sX;
	y = sY;

    }


    public void run ()
    {
	animation ();
    }
}


