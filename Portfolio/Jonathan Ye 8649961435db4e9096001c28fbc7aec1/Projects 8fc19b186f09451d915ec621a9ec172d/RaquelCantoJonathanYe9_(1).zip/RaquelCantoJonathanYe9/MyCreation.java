/*
   Name: Raquel Canto and Jonathan Ye
   Teacher: Ms. Krasteva
   Date: November 9, 2023
   Raquel and Jonathan worked on this class.

   Assignment: Simple thread example.  MyCreation.java runs the other classes.
   DO NOT put any draw commandds, etc in this file!!!
   NOTE: each class should be organized into several methods which are then executed by the run() method
   The BirdsIn class demonstrates an OVERLOADED constructor which enables the programmer to create only 1 class but alter it in many ways.
*/

import java.awt.*;
import hsa.Console;

public class MyCreation
{
    Console c;

    public void background ()
    {
	Background b = new Background (c);
    }
    
    public void introduction ()
    {
	Introduction i = new Introduction (c);
    }
    public void goodbye ()
    {
	Goodbye i = new Goodbye (c);
    }

    public void witchIn ()
    {
	WitchIn j = new WitchIn (c);
	j.start ();

	try
	{
	    j.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    public void batIn ()
    {
	Color mediumGrey = new Color (123, 123, 123);
	Color darkGrey = new Color (67, 67, 67);

	BatIn h1 = new BatIn (c, -120, 320);
	h1.start ();
	BatIn h2 = new BatIn (c, -60, 340, mediumGrey, 10);
	h2.start ();
	BatIn h3 = new BatIn (c, -120, 360, darkGrey);
	h3.start ();

	try
	{
	    h1.join ();
	}
	catch (InterruptedException e)
	{
	}
	try
	{
	    h2.join ();
	}
	catch (InterruptedException e)
	{
	}
	try
	{
	    h3.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    public void birdOut ()
    {
	Color lightBlue = new Color (120, 171, 255);
	Color lightestBlue = new Color (195, 218, 255);


	BirdOut h1 = new BirdOut (c, 420 - 120, 232);
	h1.start ();
	BirdOut h2 = new BirdOut (c, 420 - 60, 237, lightBlue);
	h2.start ();
	BirdOut h3 = new BirdOut (c, 420 - 180, 236, lightestBlue);
	h3.start ();

	try
	{
	    h1.join ();
	}
	catch (InterruptedException e)
	{
	}
	try
	{
	    h2.join ();
	}
	catch (InterruptedException e)
	{
	}
	try
	{
	    h3.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    public void birdIn ()
    {
	Color lightBlue = new Color (120, 171, 255);
	Color lightestBlue = new Color (195, 218, 255);


	BirdIn h1 = new BirdIn (c, -120, 232);
	h1.start ();
	BirdIn h2 = new BirdIn (c, -60, 237, lightBlue, 10);
	h2.start ();
	BirdIn h3 = new BirdIn (c, -180, 236, lightestBlue);
	h3.start ();

	try
	{
	    h1.join ();
	}
	catch (InterruptedException e)
	{
	}
	try
	{
	    h2.join ();
	}
	catch (InterruptedException e)
	{
	}
	try
	{
	    h3.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    public void witchFlip ()
    {
	WitchFlip b = new WitchFlip (c);
    }


    public void dragonIn ()
    {
	DragonIn j = new DragonIn (c);
	j.start ();

	try
	{
	    j.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    public void fairyIn ()
    {
	FairyIn j = new FairyIn (c);
	j.start ();

	try
	{
	    j.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    public void ufoDown ()
    {
	UFODown j = new UFODown (c);
	j.start ();

	try
	{
	    j.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    public void ufoPause ()
    {
	UFOPause j = new UFOPause (c);
	j.start ();

	try
	{
	    j.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    public void ufoUp ()
    {
	UFOUp j = new UFOUp (c);
	j.start ();

	try
	{
	    j.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    public MyCreation ()
    {
	c = new Console ("Halloween Night Flying Creatures");
    }


    public static void main (String[] args)
    {
	MyCreation z = new MyCreation ();
	z.background ();
	z.introduction();
	z.birdIn ();
	z.witchIn ();
	z.batIn ();
	z.birdOut ();
	z.witchFlip ();
	z.fairyIn ();
	z.dragonIn ();
	z.ufoDown ();
	z.ufoPause ();
	z.ufoUp ();
	z.goodbye();

    }
}
