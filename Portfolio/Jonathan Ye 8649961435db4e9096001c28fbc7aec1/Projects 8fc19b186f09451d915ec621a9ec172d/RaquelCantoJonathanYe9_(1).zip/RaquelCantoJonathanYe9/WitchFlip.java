/*
    Name: Raquel Canto and Jonathan Ye
    Date: November 8th, 2023
    Teacher: Ms. Krasteva
    Assignment #12
    Jonathan worked on this class.
*/
import java.awt.*;
import hsa.Console; //import Console class
import java.lang.*;     // to access Thread class

public class WitchFlip
{
    //Declaration of colors
    Color brightYellow = new Color (250, 255, 40);
    Color brownYellow = new Color (156, 121, 17); //broom straw
    Color lightBrown = new Color (181, 153, 94); //broomstick
    Color royalPurple = new Color (103, 78, 167); //witch dress, broom bearing
    Color mediumGreen = new Color (106, 168, 79); //witch skin
    Color darkGrey = new Color (67, 67, 67);    //witch hat + dress
    Color nightSky = new Color (0, 51, 102); //color for night sky
    private Console c;

    public void eraseWitch ()
    {
	int x = 280;
	int hair2X[] = {x + 40, x + 70, x + 50, x + 25}; //list of all x-coordinates for hair
	int hair2Y[] = {30 + 287, 30 + 287, 70 + 287, 70 + 287}; // list of all y-coordinates for hair
	int dress2X[] = {x + 50, x + 40, x + 70, x + 70, x + 75, x + 85, x + 70}; //list of all x-coordinates for dress
	int dress2Y[] = {50 + 287, 90 + 287, 100 + 287, 80 + 287, 85 + 287, 75 + 287, 55 + 287}; // list of all y-coordinates for dress
	int dressLining2X[] = {x + 42, x + 40, x + 70, x + 70}; //list of all x-coordinates for dress lining
	int dressLining2Y[] = {80 + 287, 90 + 287, 100 + 287, 90 + 287}; // list of all y-coordinates for dress lining
	int broomBearing2X[] = {x + 30, x + 30, x + 20, x + 20}; //list of all x-coordinates for broom bearing
	int broomBearing2Y[] = {80 + 287, 90 + 287, 95 + 287, 75 + 287}; // list of all y-coordinates for broom bearing
	int sleeveLining2X[] = {x + 75, x + 85, x + 80, x + 70}; //list of all x-coordinates for sleeve lining
	int sleeveLining2Y[] = {85 + 287, 75 + 287, 70 + 287, 80 + 287}; // list of all y-coordinates for sleeve lining
	int hat2X[] = {x + 40, x + 50, x + 70}; //list of all x-coordinates for the hat
	int hat2Y[] = {10 + 287, 30 + 287, 30 + 287}; // list of all y-coordinates for the hat
	int straw2X[] = {x + 20, x + 20, x + 5, x + 10, x, x + 10, x, x + 10, x, x + 10, x + 5}; //list of all x-coordinates for broom straw
	int straw2Y[] = {90 + 287, 80 + 287, 70 + 287, 75 + 287, 75 + 287, 80 + 287, 85 + 287, 90 + 287, 95 + 287, 95 + 287, 100 + 287}; // list of all y-coordinates for broom straw

	c.setColor (nightSky); //+x360 and +y287
	c.fillPolygon (hair2X, hair2Y, 4); //hair
	c.fillPolygon (dress2X, dress2Y, 7); //dress
	c.fillPolygon (broomBearing2X, broomBearing2Y, 4); //broom bearing
	c.fillPolygon (hat2X, hat2Y, 3); //hat
	c.fillOval (40 + x, 25 + 287, 40, 10); //hat
	c.fillOval (x + 50, 95 + 287, 5, 10); //left leg
	c.fillOval (x + 60, 95 + 287, 5, 10); //right leg
	c.fillPolygon (straw2X, straw2Y, 11); //broom straw
    }

    public void drawWitch ()
    {
	int x = 400;

	int hairX[] = {x - 40, x - 70, x - 50, x - 25}; //list of all x-coordinates for hair
	int hairY[] = {30 + 287, 30 + 287, 70 + 287, 70 + 287}; // list of all y-coordinates for hair
	int dressX[] = {x - 50, x - 40, x - 70, x - 70, x - 75, x - 85, x - 70}; //list of all x-coordinates for dress
	int dressY[] = {50 + 287, 90 + 287, 100 + 287, 80 + 287, 85 + 287, 75 + 287, 55 + 287}; // list of all y-coordinates for dress
	int dressLiningX[] = {x - 42, x - 40, x - 70, x - 70}; //list of all x-coordinates for dress lining
	int dressLiningY[] = {80 + 287, 90 + 287, 100 + 287, 90 + 287}; // list of all y-coordinates for dress lining
	int broomBearingX[] = {x - 30, x - 30, x - 20, x - 20}; //list of all x-coordinates for broom bearing
	int broomBearingY[] = {80 + 287, 90 + 287, 95 + 287, 75 + 287}; // list of all y-coordinates for broom bearing
	int sleeveLiningX[] = {x - 75, x - 85, x - 80, x - 70}; //list of all x-coordinates for sleeve lining
	int sleeveLiningY[] = {85 + 287, 75 + 287, 70 + 287, 80 + 287}; // list of all y-coordinates for sleeve lining
	int hatX[] = {x - 40, x - 50, x - 70}; //list of all x-coordinates for the hat
	int hatY[] = {10 + 287, 30 + 287, 30 + 287}; // list of all y-coordinates for the hat
	int strawX[] = {x - 20, x - 20, x - 5, x - 10, x, x - 10, x, x - 10, x, x - 10, x - 5}; //list of all x-coordinates for broom straw
	int strawY[] = {90 + 287, 80 + 287, 70 + 287, 75 + 287, 75 + 287, 80 + 287, 85 + 287, 90 + 287, 95 + 287, 95 + 287, 100 + 287}; // list of all y-coordinates for broom straw

	//Broom
	//Broom Stick
	c.setColor (lightBrown);
	c.fillRoundRect (x - 20 - 100, 80 + 287, 100, 10, 45, 45); //broom stick
	//Broom Bearing
	c.setColor (royalPurple);
	c.fillPolygon (broomBearingX, broomBearingY, 4);
	//Broom Straw
	c.setColor (brownYellow);
	c.fillPolygon (strawX, strawY, 11);

	//Skin
	c.setColor (mediumGreen);
	c.fillOval (x - 45 - 30, 287 + 25, 30, 30); //head
	c.fillOval (x - 50 - 5, 95 + 287, 5, 10); //left leg
	c.fillOval (x - 60 - 5, 95 + 287, 5, 10); //right leg
	c.fillOval (x - 75 - 15, 75 + 287, 15, 15); //hand

	//Dress
	c.setColor (darkGrey);
	c.fillPolygon (dressX, dressY, 7);

	//Dress Lining
	c.setColor (royalPurple);
	//Dress
	c.fillPolygon (dressLiningX, dressLiningY, 4);
	//Sleeve
	c.fillPolygon (sleeveLiningX, sleeveLiningY, 4);

	//Hair
	c.setColor (Color.BLACK);
	c.fillPolygon (hairX, hairY, 4);

	//Hat
	c.setColor (darkGrey);
	c.fillOval (40 + x - 120, 25 + 287, 40, 10);
	c.fillPolygon (hatX, hatY, 3);

    }


    public WitchFlip (Console con)  //constructor
    {
	c = con;
	eraseWitch ();
	drawWitch ();
    }
}




