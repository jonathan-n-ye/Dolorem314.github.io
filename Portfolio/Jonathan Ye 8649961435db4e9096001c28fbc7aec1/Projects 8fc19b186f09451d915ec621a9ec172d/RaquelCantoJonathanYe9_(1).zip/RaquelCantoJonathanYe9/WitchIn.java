/*
   Name: Raquel Canto and Jonathan Ye
   Teacher: Ms. Krasteva
   Date: November 9, 2023
   Raquel and Jonathan worked on this class.
*/
import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class WitchIn extends Thread
{
    private Console c;

    //Colours Declaration Section
    Color brownYellow = new Color (156, 121, 17); //broom straw
    Color lightBrown = new Color (181, 153, 94); //broomstick
    Color royalPurple = new Color (103, 78, 167); //witch dress, broom bearing
    Color mediumGreen = new Color (106, 168, 79); //witch skin
    Color darkGrey = new Color (67, 67, 67);    //witch hat + dress
    Color nightSky = new Color (0, 51, 102); //color for night sky

    public void animation ()
    {

	for (int i = 0 ; i <= 280 ; i++)
	{
	    broom (i);
	    text ();
	    witch (i);
	    delay();
	    eraseTrail (i);
	}
    }

    public void witch (int x)
    {
	int hairX[] = {x + 40, x + 70, x + 50, x + 25}; //list of all x-coordinates for hair
	int hairY[] = {30 + 287, 30 + 287, 70 + 287, 70 + 287}; // list of all y-coordinates for hair
	int dressX[] = {x + 50, x + 40, x + 70, x + 70, x + 75, x + 85, x + 70}; //list of all x-coordinates for dress
	int dressY[] = {50 + 287, 90 + 287, 100 + 287, 80 + 287, 85 + 287, 75 + 287, 55 + 287}; // list of all y-coordinates for dress
	int dressLiningX[] = {x + 42, x + 40, x + 70, x + 70}; //list of all x-coordinates for dress lining
	int dressLiningY[] = {80 + 287, 90 + 287, 100 + 287, 90 + 287}; // list of all y-coordinates for dress lining
	int sleeveLiningX[] = {x + 75, x + 85, x + 80, x + 70}; //list of all x-coordinates for sleeve lining
	int sleeveLiningY[] = {85 + 287, 75 + 287, 70 + 287, 80 + 287}; // list of all y-coordinates for sleeve lining
	int hatX[] = {x + 40, x + 50, x + 70}; //list of all x-coordinates for the hat
	int hatY[] = {10 + 287, 30 + 287, 30 + 287}; // list of all y-coordinates for the hat

	//Skin
	c.setColor (mediumGreen);
	c.fillOval (x + 45, 287 + 25, 30, 30); //head
	c.fillOval (x + 50, 95 + 287, 5, 10); //left leg
	c.fillOval (x + 60, 95 + 287, 5, 10); //right leg
	c.fillOval (x + 75, 75 + 287, 15, 15); //hand

	//Dress
	c.setColor (darkGrey);
	c.fillPolygon (dressX, dressY, 7);

	//Dress Lining
	c.setColor (royalPurple);
	//Dress
	c.fillPolygon (dressLiningX, dressLiningY, 4);
	//Sleeve
	c.fillPolygon (sleeveLiningX, sleeveLiningY, 4);

	//Hair
	c.setColor (Color.BLACK);
	c.fillPolygon (hairX, hairY, 4);

	//Hat
	c.setColor (darkGrey);
	c.fillOval (40 + x, 25 + 287, 40, 10);
	c.fillPolygon (hatX, hatY, 3);

    }


    public void broom (int x)
    {
	int broomBearingX[] = {x + 30, x + 30, x + 20, x + 20}; //list of all x-coordinates for broom bearing
	int broomBearingY[] = {80 + 287, 90 + 287, 95 + 287, 75 + 287}; // list of all y-coordinates for broom bearing
	int strawX[] = {x + 20, x + 20, x + 5, x + 10, x, x + 10, x, x + 10, x, x + 10, x + 5}; //list of all x-coordinates for broom straw
	int strawY[] = {90 + 287, 80 + 287, 70 + 287, 75 + 287, 75 + 287, 80 + 287, 85 + 287, 90 + 287, 95 + 287, 95 + 287, 100 + 287}; // list of all y-coordinates for broom straw

	//Broom Stick
	c.setColor (lightBrown);
	c.fillRoundRect (x + 20, 80 + 287, 100, 10, 45, 45); //broom stick
	//Broom Bearing
	c.setColor (royalPurple);
	c.fillPolygon (broomBearingX, broomBearingY, 4);
	//Broom Straw
	c.setColor (brownYellow);
	c.fillPolygon (strawX, strawY, 11);
    }


    public void text ()
    {
	c.setFont (new Font ("Courier", 1, 13));
	c.setColor (Color.WHITE);
	c.drawString ("Witch: Well, well, a flock of birds. I'll teach them", 10, 415);
	c.drawString ("to cross paths with me! Fly, my pretties! Attack!", 10, 430);
    }


    public void delay ()
    {
	try
	{
	    Thread.sleep (10);
	}
	catch (Exception e)
	{
	}
    }


    public void eraseTrail (int x)
    {
	int hairX[] = {x + 40, x + 70, x + 50, x + 25}; //list of all x-coordinates for hair
	int hairY[] = {30 + 287, 30 + 287, 70 + 287, 70 + 287}; // list of all y-coordinates for hair
	int dressX[] = {x + 50, x + 40, x + 70, x + 70, x + 75, x + 85, x + 70}; //list of all x-coordinates for dress
	int dressY[] = {50 + 287, 90 + 287, 100 + 287, 80 + 287, 85 + 287, 75 + 287, 55 + 287}; // list of all y-coordinates for dress
	int hatX[] = {x + 40, x + 50, x + 70}; //list of all x-coordinates for the hat
	int hatY[] = {10 + 287, 30 + 287, 30 + 287}; // list of all y-coordinates for the hat
	int broomBearingX[] = {x + 30, x + 30, x + 20, x + 20}; //list of all x-coordinates for broom bearing
	int broomBearingY[] = {80 + 287, 90 + 287, 95 + 287, 75 + 287}; // list of all y-coordinates for broom bearing
	int strawX[] = {x + 20, x + 20, x + 5, x + 10, x, x + 10, x, x + 10, x, x + 10, x + 5}; //list of all x-coordinates for broom straw
	int strawY[] = {90 + 287, 80 + 287, 70 + 287, 75 + 287, 75 + 287, 80 + 287, 85 + 287, 90 + 287, 95 + 287, 95 + 287, 100 + 287}; // list of all y-coordinates for broom straw

	if (x != 280)
	{
	    c.setColor (nightSky); //+x360 and +y287
	    c.fillPolygon (hairX, hairY, 4); //hair
	    c.fillPolygon (dressX, dressY, 7); //dress
	    c.fillPolygon (broomBearingX, broomBearingY, 4); //broom bearing
	    c.fillPolygon (hatX, hatY, 3); //hat
	    c.fillOval (40 + x, 25 + 287, 40, 10); //hat
	    c.fillOval (x + 50, 95 + 287, 5, 10); //left leg
	    c.fillOval (x + 60, 95 + 287, 5, 10); //right leg
	    c.fillPolygon (strawX, strawY, 11); //broom straw
	}
	
    }

    public WitchIn (Console con)
    {
	c = con;
    }


    public void run ()
    {
	animation ();
    }
}

