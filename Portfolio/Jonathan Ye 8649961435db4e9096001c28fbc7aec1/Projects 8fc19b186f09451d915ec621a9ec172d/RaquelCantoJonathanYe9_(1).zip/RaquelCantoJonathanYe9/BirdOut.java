/*
   Name: Raquel Canto and Jonathan Ye
   Teacher: Ms. Krasteva
   Date: November 9, 2023
   Jonathan worked on this class.

This class is has 3 overloaded constructors!!!
The basic constructor creates a bird in a specific predetermined location.
The 2nd constructor allows a parameter pass to change the bird color.
The 3rd constructor creates a bird with a specific color and a time delay to
control the speed of its movement during the animation.

*/
import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class BirdOut extends Thread
{
    private Console c;
    private Color birdColor;
    Color nightSky = new Color (0, 51, 102);
    private int delay;
    private int x;
    private int y;

    public void bird ()
    {
	//local colour variable used for sky
	c.setColor (nightSky);
	c.fillRect (180, 230, 200, 67);
	for (; x > -100 ; x--)
	{
	    drawBird ();
	    delay ();
	    if (x != 400 - 1)
	    {
		fillTrail ();
	    }
	}
    }


    public void delay ()
    {
	try
	{
	    sleep (delay);
	}
	catch (Exception e)
	{
	}
    }


    public void drawBird ()
    {
	//body
	c.setColor (birdColor);
	c.fillOval (-50 + x, 25 + y, 15, 10); // Change the sign of x position
	c.setColor (birdColor);

	c.fillRect (-13 + x, 27 + y, 3, 6);  // Change the sign of x position
	int wingX[] = {0 + x, -40 + x, -35 + x, -40 + x, 0 + x, -25 + x, -25 + x}; // Change the sign of x position
	int wingY[] = {0 + y, 10 + y, 30 + y, 50 + y, 60 + y, 45 + y, 15 + y};
	c.setColor (birdColor);

	c.fillPolygon (wingX, wingY, 7);
	int tailX[] = { - 15 + x, -15 + x, -35 + x}; // Change the sign of x position
	int tailY[] = {25 + y, 35 + y, 30 + y};
	c.setColor (birdColor);

	c.fillPolygon (tailX, tailY, 3);
	c.setColor (Color.BLACK);
	c.drawLine (-15 + x, 25 + y, -15 + x, 35 + y); // Change the sign of x position
    }


    public void fillTrail ()
    {
	int wingX[] = {0 + x, -40 + x, -35 + x, -40 + x, 0 + x, -25 + x, -25 + x}; // Change the sign of x position
	int wingY[] = {0 + y, 10 + y, 30 + y, 50 + y, 60 + y, 45 + y, 15 + y};
	int tailX[] = { - 15 + x, -15 + x, -35 + x}; // Change the sign of x position
	int tailY[] = {25 + y, 35 + y, 30 + y};
	c.setColor (nightSky);
	c.drawRect (-12 + x, 27 + y, 3, 6);  // Change the sign of x position
	c.setColor (nightSky);
	c.drawPolygon (wingX, wingY, 7);
	c.setColor (nightSky);
	c.drawPolygon (tailX, tailY, 3);
	c.setColor (nightSky);
	c.drawLine (-15 + x, 25 + y, -15 + x, 35 + y);
    }



    //basic bird
    public BirdOut (Console con, int sX, int sY)
    {
	c = con;
	birdColor = new Color (60, 120, 216);
	x = sX;
	y = sY;
	delay = 20;
    }


    // bird with a Color parameter
    public BirdOut (Console con, int sX, int sY, Color n, int d)
    {
	c = con;
	birdColor = n;
	delay = d;
	x = sX;
	y = sY;
    }


    // bird with a Color parameter, and a new delay time
    public BirdOut (Console con, int sX, int sY, Color n)
    {
	c = con;
	birdColor = n;
	delay = 20;
	x = sX;
	y = sY;

    }


    public void run ()
    {
	bird ();
    }
}
