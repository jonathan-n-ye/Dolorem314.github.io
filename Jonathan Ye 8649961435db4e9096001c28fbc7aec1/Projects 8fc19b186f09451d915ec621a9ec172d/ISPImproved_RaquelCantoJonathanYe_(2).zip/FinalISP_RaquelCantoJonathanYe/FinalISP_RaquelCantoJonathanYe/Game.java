// Importing necessary packages and libraries
import hsa.*;                    // hsa package for console-based input and output
import javax.swing.*;            // javax.swing package for graphical user interfaces (GUI)
import java.awt.*;               // java.awt package for creating GUI components
import java.awt.image.*;         // java.awt.image package for working with images
import java.io.*;                // java.io package for input and output operations, including file handling
import javax.imageio.ImageIO;    // javax.imageio package for reading and writing images
import java.util.*;              // java.util package for utility classes and d



/*
Description: The Game class represents a simple platformer where players navigate a
character through levels by answering multiple-choice questions. The character moves
vertically, aiming to land on the correct answer block to progress. Colorful blocks
represent answer choices, and falling off the screen results in a game over.

Variable Name  |    Type     | Function
-----------------------------------
lightYellow    | Color       | Represents the color (255, 238, 177)
peach          | Color       | Represents the color (241, 222, 205)
oakBrown       | Color       | Represents the color (171, 142, 56)
lightGrey      | Color       | Represents the color (166, 166, 166)
dullGreen      | Color       | Represents the color (119, 162, 144)
lightBlue      | Color       | Represents the color (106, 184, 242)
mediumGrey     | Color       | Represents the color (116, 116, 116)
darkGrey       | Color       | Represents the color (84, 84, 84)
darkBrown      | Color       | Represents the color (90, 66, 63)
brightBlue     | Color       | Represents the color (46, 133, 198)
brightGreen    | Color       | Represents the color (0, 193, 128)
darkGreen      | Color       | Represents the color (0, 99, 66)
nightSky       | Color       | Represents the color (0, 67, 137)
magenta        | Color       | Represents the color (202, 0, 185)
lightPink      | Color       | Represents the color (255, 163, 198)
darkRed        | Color       | Represents the color (105, 0, 26)
lime           | Color       | Represents the color (0, 223, 70)
pinkPeach      | Color       | Represents the color (255, 210, 195)
orange         | Color       | Represents the color (255, 153, 0)
yellow         | Color       | Represents the color (255, 255, 0)

questions      | String[]    | Array storing all the quiz questions
answers        | String[][]  | 2D Array storing all the quiz answers
multipleChoices| int[]       | Array indicating the number of choices for each question
gameLevel      | int         | Current level in the quiz

c              | Console     | Creates a new instance of Console for use by the class
xy             | int[]       | Coordinates of the character


NEW CITATION:

*/


class Game
{
    //Colour Variables
    Color lightYellow = new Color (255, 238, 177);
    Color peach = new Color (241, 222, 205);
    Color oakBrown = new Color (171, 142, 56);
    Color lightGrey = new Color (166, 166, 166);
    Color dullGreen = new Color (119, 162, 144);
    Color lightBlue = new Color (106, 184, 242);
    Color mediumGrey = new Color (116, 116, 116);
    Color darkGrey = new Color (84, 84, 84);
    Color darkBrown = new Color (90, 66, 63);
    Color brightBlue = new Color (46, 133, 198);
    Color brightGreen = new Color (0, 193, 128);
    Color darkGreen = new Color (0, 99, 66);
    Color nightSky = new Color (0, 67, 137);
    Color magenta = new Color (202, 0, 185);
    Color lightPink = new Color (255, 163, 198);
    Color darkRed = new Color (105, 0, 26);
    Color lime = new Color (0, 223, 70);
    Color pinkPeach = new Color (255, 210, 195);
    Color orange = new Color (255, 153, 0);
    Color yellow = new Color (255, 255, 0);


    //Questions and answers
    String[] questions = {
	"1. What did the Great Spirit do to shape the Earth?",
	"2. How was the Earth formed in the Indigenous story?",
	"3. Why is North America sometimes called 'Turtle Island'?",
	"4. What can tricksters be in Indigenous stories?",
	"5. What ability do transformers have in Indigenous tales?",
	"6. What is role that Shamans play in Indigenous cultures?",
	"7. What do Shamans do in their communities?",
	"8. During puberty, what do some Indigenous boys do?",
	"9. What are guardian spirits often in Indigenous stories?",
	"10. How do boys purify themselves during their quest?",
	"11. What is the main goal of boys during their quest?",
	"12. What is a benefit of guardian spirits?",
	"13. What do Shamans do during religious ceremonies?",
	"14. What special powers do Shamans have in Indigenous cultures?",
	"15. Why is the Earth Diver myth significant in creation stories?",
	"16. How are transformers different from tricksters?",
	"17. What is a common characteristic of Tricksters?",
	"18. How do guardian spirits help someone's well-being?",
	"19. What do Shamans do to address community problems in?",
	"20. What makes Shamans different in Indigenous communities?",
	"21. Why is the Earth being on a Turtle's back significant?",
	"22. What's the main purpose of fasting and praying during puberty?",
	"23. How do Indigenous communities refer to North America in stories?",
	"24. What's a characteristic of guardian spirits?",
	"25. What do Shamans predict in Indigenous communities?"
	};

    String[] [] answers = {
	    {"a. Planted seeds",
	    "b. Created mountains",
	    "c. Dived into waters to get mud",
	    "d. Sculpted human beings"},  //1
	    {"a. Using mud from waters",
	    "b. With sunlight",
	    "c. By fire",
	    "d. Through magic"},  //2
	    {"a. Turtles are sacred",
	    "b. The continent looks like a turtle",
	    "c. Turtles bring good luck",
	    "d. Earth was formed on a turtle's back"},  //3
	    {"a. Always helpful",
	    "b. Strictly human",
	    "c. Anything",
	    "d. Only troublemakers"},  //4
	    {"a. Shape-shifting abilities",
	    "b. Invisibility",
	    "c. Immortality",
	    "d. Superhuman strength"},  //5
	    {"a. Warriors",
	    "b. Merchants",
	    "c. Healers",
	    "d. Political leaders"},  //6
	    {"a. Train warriors",
	    "b. Predict hunt outcomes",
	    "c. Fight monsters",
	    "d. Manage farms"},  //7
	    {"a. Exercise a lot",
	    "b. Go to school",
	    "c. Stay isolated fasting & praying",
	    "d. Attend parties"},  //8
	    {"a. Human-like",
	    "b. Silent and mysterious",
	    "c. Urban beings",
	    "d. Animals or mythical figures"},  //9
	    {"a. Avoid water",
	    "b. Use fire",
	    "c. Wash themselves in streams",
	    "d. Stay indoors"},  //10
	    {"a. Become rich",
	    "b. Seek revenge",
	    "c. Encounter a guardian spirit",
	    "d. Master art skills"},  //11
	    {"a. Cooking skills",
	    "b. Success in hunting",
	    "c. Physical strength",
	    "d. Farming mastery"},  //12
	    {"a. Lead debates",
	    "b. Entertain people",
	    "c. Officiate and guide the ceremony",
	    "d. Negotiate trades"},  //13
	    {"a. Super strength",
	    "b. Healing powers",
	    "c. Telepathy with animals",
	    "d. Invisibility"},  //14
	    {"a. Shows struggles between good/evil",
	    "b. Shows life and death cycles",
	    "c. Shows the importance of farming",
	    "d. Explains how Earth formed"},  //15
	    {"a. Always wise",
	    "b. Transformers are originally humans",
	    "c. Strictly villains",
	    "d. Immortal"},  //16
	    {"a. Always wise",
	    "b. Strict rule-followers",
	    "c. Can be anything",
	    "d. Exclusively male"},  //17
	    {"a. Grant wealth",
	    "b. Provide protection and guidance",
	    "c. Enhance physical beauty",
	    "d. Control natural elements"},  //18
	    {"a. Perform healing ceremonies",
	    "b. Engage in debates",
	    "c. Lead military campaigns",
	    "d. Organize festivals"},  //19
	    {"a. Wealth",
	    "b. They are prophets",
	    "c. Farming skills",
	    "d. Physical strength"},  //20
	    {"a. Turtles are creators",
	    "b. Represents land and water balance",
	    "c. Symbolizes Earth resting on a Turtle",
	    "d. Turtles are wise beings"},  //21
	    {"a. Show bravery",
	    "b. Seek a guardian spirit",
	    "c. Improve appearance",
	    "d. Prepare for leadership"},  //22
	    {"a. Eagle's Nest",
	    "b. Bear Haven",
	    "c. Turtle Island",
	    "d. Serpent's Back"},  //23
	    {"a. Often human-like",
	    "b. Evil intentions",
	    "c. Control the weather",
	    "d. Often animals/mythological figures"},  //24
	    {"a. Hunt outcomes",
	    "b. Agricultural yields",
	    "c. Weather patterns",
	    "d. Success in military campaigns"}  //25
	};

    int[] multipleChoices = {1, 3, 1, 4, 3, 1, 3, 2, 3, 4, 3, 3, 2, 3, 2, 4, 2, 3, 2, 1, 2, 3, 2, 3, 4};

    //current game level and answer/next answer
    int gameLevel = 0;

    //Console
    Console c;

    //Character location
    int[] xy = {120, 50};

    /*
    This is the helper method for the class. It sets Console up.

    No local variables
    */
    public Game (Console a)
    {
	c = a; //sets Console c to be parameter from the IndigenousCultureJourney class
    }


    /*
    Description: The startGame method sets up a game and runs it.
    It has a moving character on a pogo stick, colored blocks, and a
    question display. It creates a seperate thread for user input handling
    and employs a while loop to continuously update the game animations.
    Upon touching lava, the game stops, displays the score, and draws
    skull graphics representing a game over screen. The method waits for
    user input before returning.

    Name               Datatype         Use
    gameLevel          int              Keeps track of the current level in the game
    blockColours       Color[]          Array containing colors for different blocks
    characterImage     BufferedImage    Image of the game character
    tempCheck          boolean          Temporary boolean variable for checking
    thread1            CheckKey         Thread for checking keyboard input
    e                  Exception        Exception variable for error handling
    skullX             int[]            x-value array for outline of skull
    skullX1            int[]            x-value array for outline of skull
    skullY             int[]            y-value array for outline of skull
    skullY1            int[]            y-value array for outline of skull

    Credits: Jonathan + Raquel(Skulls)
    */
    public void startGame ()
    {
	//Variable Declaration
	gameLevel = 0;

	Color[] blockColours = {
	    Color.WHITE, Color.DARK_GRAY, Color.BLACK,
	    lightYellow, peach, lightPink, pinkPeach, magenta,
	    dullGreen, mediumGrey, darkGreen, brightGreen, lime,
	    lightGrey, darkBrown, brightBlue, nightSky, darkRed,
	    orange, yellow, lime, brightGreen, dullGreen, brightBlue, lightGrey
	    };

	//Game setup
	gameBackground (); //Draw background
	CheckKey thread1 = new CheckKey (c, xy); //Creates new object using CheckKey Class
	thread1.start (); //Runs the CheckKey Class

	drawGameQuestion (); //Draws first question

	try
	{
	    //Setup character image for animation
	    BufferedImage characterImage = ImageIO.read (new File ("gameCharacter.png"));

	    /*
	    This while loop is the game loop, controlling the movement and
	    interaction of our character with the blocks. The loop runs
	    indefinitely and performs several tasks in each iteration.

	    1. The loop starts with a short pause (Thread.sleep(10)) to control the loop's speed
	    2. It erases the character's trail and draws the character at its updated position
	    3. It draws a series of blocks on the screen, with colors determined by the game level (In case character goes over it)
	    4. The character's vertical position is adjusted based on its velocity, simulating gravity
		a. Handles collision scenarios with blocks (Won't fall if on top of correct block)
	    6. If the character touches lava, the loop breaks

	    Also includes additional code for handling levels, block colors
	    & displaying questions.
	    */
	    while (true) //runs forever until broken out of
	    {

		//Pause
		try

		{
		    Thread.sleep (20); //Sleep for 10 ms
		}
		catch (InterruptedException e)  //Catches exception
		{
		}

		//Erase trail
		c.setColor (lightBlue); //set color to light blue
		c.fillRect (xy [0] - 40, 450 - xy [1] - 73, 79, 93); //draw rectangle surrounding character

		//Draws object
		c.drawImage (characterImage, xy [0] - 20, 450 - xy [1] - 63, null); //draws the character


		//BLOCKS
		c.setColor (blockColours [gameLevel % 25]); //bottom set
		c.fillRect (66, 450, 80, 20); //rect 1
		c.fillRect (212, 450, 80, 20); //rect 2
		c.fillRect (358, 450, 80, 20); //rect 3
		c.fillRect (504, 450, 80, 20); //rect 4


		c.setColor (blockColours [(gameLevel + 1) % 25]); //top set

		c.fillRect (66, 300, 80, 20); //rect 1
		c.fillRect (212, 300, 80, 20); //rect 2
		c.fillRect (358, 300, 80, 20); //rect 3
		c.fillRect (504, 300, 80, 20); //rect 4
		gameLevel += 2; //temporary adjustment
		//Sets color to white for specific dark coloured blocks
		if (gameLevel == 2 ||
			gameLevel == 3 ||
			gameLevel == 8 ||
			gameLevel == 10 ||
			gameLevel == 11 ||
			gameLevel == 15 ||
			gameLevel == 17 ||
			gameLevel == 18)
		{
		    c.setColor (Color.WHITE); //sets color to white
		}
		//Sets color to black for light coloured blocks
		else
		{
		    c.setColor (Color.BLACK); //sets color to black
		}
		gameLevel -= 2; //set adjustment back
		c.setFont (new Font ("Sitka Text", Font.BOLD, 17));
		c.drawString ("a", 66 + 35, 300 + 15); //a
		c.drawString ("b", 212 + 35, 300 + 15); //b
		c.drawString ("c", 358 + 35, 300 + 15); //c
		c.drawString ("d", 504 + 35, 300 + 15); //d
		//BLOCKS END

		//Checks if not on top of block
		if (!(xy [1] <= 0) && !(xy [1] >= 155 && xy [1] <= 160 && thread1.vel < 0 && checkBlock (true)))
		{
		    thread1.vel -= 0.1; //Subtracts from velocity
		    xy [1] += (int) thread1.vel / 2; //Updates the y value
		}
		//If on block
		else
		{
		    if (xy [1] <= 0 && checkBlock ()) //If on bottom set of blocks and block is correct
		    {
			xy [1] = 10; //Sets the y value to be on top of block (accounts for going past the block a little bit)
		    }
		    else if (xy [1] <= 0) //If on the wrong bottom block + touching lava
		    {
			break; //End game
		    }
		    else //Otherwise on top set
		    {
			c.drawImage (characterImage, xy [0] - 20, 450 - xy [1] - 63, null); //Draws character image

			//BLOCKS
			c.setColor (blockColours [gameLevel % 25]); //bottom set
			c.fillRect (66, 450, 80, 20); //rect 1
			c.fillRect (212, 450, 80, 20); //rect 2
			c.fillRect (358, 450, 80, 20); //rect 3
			c.fillRect (504, 450, 80, 20); //rect 4


			c.setColor (blockColours [(gameLevel + 1) % 25]); //top set

			c.fillRect (66, 300, 80, 20); //rect 1
			c.fillRect (212, 300, 80, 20); //rect 2
			c.fillRect (358, 300, 80, 20); //rect 3
			c.fillRect (504, 300, 80, 20); //rect 4
			gameLevel += 2; //temporary adjustment
			//Sets color to white for specific dark coloured blocks
			if (gameLevel == 2 ||
				gameLevel == 3 ||
				gameLevel == 8 ||
				gameLevel == 10 ||
				gameLevel == 11 ||
				gameLevel == 15 ||
				gameLevel == 17 ||
				gameLevel == 18)
			{
			    c.setColor (Color.WHITE); //sets color to white
			}
			//Sets color to black for light coloured blocks
			else
			{
			    c.setColor (Color.BLACK); //sets color to black
			}
			gameLevel -= 2; //set adjustment back
			c.setFont (new Font ("Sitka Text", Font.BOLD, 17));
			c.drawString ("a", 66 + 35, 300 + 15); //a
			c.drawString ("b", 212 + 35, 300 + 15); //b
			c.drawString ("c", 358 + 35, 300 + 15); //c
			c.drawString ("d", 504 + 35, 300 + 15); //d
			//BLOCKS END

			//Pause code (1 second)
			try

			{
			    Thread.sleep (1000); //sleep
			}
			catch (InterruptedException e)  //catch exception
			{
			}
			c.setColor (lightBlue); //set color to light blue
			c.fillRect (xy [0] - 40, 450 - xy [1] - 63, 79, 73); //draw cover for character
			xy [1] = 10;

			//Reset
			gameLevel++; //resets level to be increased
			drawGameQuestion (); //resets question

			//BLOCKS
			c.setColor (blockColours [gameLevel % 25]); //bottom set
			c.fillRect (66, 450, 80, 20); //rect 1
			c.fillRect (212, 450, 80, 20); //rect 2
			c.fillRect (358, 450, 80, 20); //rect 3
			c.fillRect (504, 450, 80, 20); //rect 4


			c.setColor (blockColours [(gameLevel + 1) % 25]); //top set

			c.fillRect (66, 300, 80, 20); //rect 1
			c.fillRect (212, 300, 80, 20); //rect 2
			c.fillRect (358, 300, 80, 20); //rect 3
			c.fillRect (504, 300, 80, 20); //rect 4
			gameLevel += 2; //temporary adjustment
			//Sets color to white for specific dark coloured blocks
			if (gameLevel == 2 ||
				gameLevel == 3 ||
				gameLevel == 8 ||
				gameLevel == 10 ||
				gameLevel == 11 ||
				gameLevel == 15 ||
				gameLevel == 17 ||
				gameLevel == 18)
			{
			    c.setColor (Color.WHITE); //sets color to white
			}
			//Sets color to black for light coloured blocks
			else
			{
			    c.setColor (Color.BLACK); //sets color to black
			}
			gameLevel -= 2; //set adjustment back
			c.setFont (new Font ("Sitka Text", Font.BOLD, 17));
			c.drawString ("a", 66 + 35, 300 + 15); //a
			c.drawString ("b", 212 + 35, 300 + 15); //b
			c.drawString ("c", 358 + 35, 300 + 15); //c
			c.drawString ("d", 504 + 35, 300 + 15); //d
			//BLOCKS END
		    }

		    while (thread1.vel < 10 && checkBlock ()) //while the velocity does not increase and it is still on the block, it will continuosly refresh
		    {
			//draws character
			c.drawImage (characterImage, xy [0] - 20, 450 - xy [1] - 63, null);

			//Pauses program
			try

			{
			    Thread.sleep (100); //sleep 100 ms
			}
			catch (Exception e)  //catches exception
			{
			}
			//Covers trail
			c.setColor (lightBlue); //set color to light blue
			c.fillRect (xy [0] - 40, 450 - xy [1] - 63, 79, 83); //fills rect
			
			//BLOCKS
			c.setColor (blockColours [gameLevel % 25]); //bottom set
			c.fillRect (66, 450, 80, 20); //rect 1
			c.fillRect (212, 450, 80, 20); //rect 2
			c.fillRect (358, 450, 80, 20); //rect 3
			c.fillRect (504, 450, 80, 20); //rect 4
			//BLOCKS END


		    }
		}
	    }

	}
	catch (IOException e)
	{
	}

	// GAME OVER
	c.clear (); //Clear console screen

	c.setColor (Color.BLACK); //Background Color

	c.setFont (new Font ("Sitka Text", 1, 60)); //Sets font
	c.drawString ("GAME OVER", 140, 130); // Draws "GAME OVER" text

	c.setFont (new Font ("Sitka Text", 0, 40)); //Sets font
	c.drawString ("Your score is: ", 195, 180); // Draws "Your score is:" text
	c.drawString ("" + gameLevel, 305, 230);

	// Skull drawing at different positions

	int skullX[] = {36, 36, 144, 144, 162, 162, 180, 180, 144, 144, 36, 36, 0, 0, 18, 18}; //array containing x-coordinates for big skulls
	int skullY[] = {18, 0, 0, 18, 18, 36, 36, 108, 108, 180, 180, 108, 108, 36, 36, 18}; //array containing y-coordinates for big skulls
	c.setColor (Color.BLACK); //sets colour to black

	//First Skull
	for (int i = 0 ; i < skullX.length ; i++) //for loop going through every value in the array
	{
	    skullX [i] += 10; //adds 10 to every x-coordinate in the array
	    skullY [i] += 260; //adds 260 to every y-coordinate in the array
	} //closes for loop
	c.drawPolygon (skullX, skullY, 16); //draws first skull outline
	c.fillRect (46, 324, 36, 36); //draws big part of first skull's left eye
	c.fillRect (118, 324, 36, 36); //draws big part of first skull's right eye
	c.fillRect (28, 342, 18, 18); //draws small part of first skull's left eye
	c.fillRect (154, 342, 18, 18); //draws small part of first skull's right eye
	c.fillRect (64, 404, 18, 36); //draws first skull's first black mouth hole
	c.fillRect (91, 404, 18, 36); //draws first skull's second black mouth hole
	c.fillRect (118, 404, 18, 36); //draws first skull's third black mouth hole

	//Fourth Skull
	for (int i = 0 ; i < skullX.length ; i++) //for loop going through every value in the array
	{
	    skullX [i] += 440; //adds 440 to every x-coordinate in the array
	} //closes for loop
	c.drawPolygon (skullX, skullY, 16); //draws fourth skull outline
	c.fillRect (486, 324, 36, 36); //draws big part of fourth skull's left eye
	c.fillRect (558, 324, 36, 36); //draws big part of fourth skull's right eye
	c.fillRect (468, 342, 18, 18); //draws small part of fourth skull's left eye
	c.fillRect (594, 342, 18, 18); //draws small part of fourth skull's right eye
	c.fillRect (504, 404, 18, 36); //draws fourth skull's first black mouth hole
	c.fillRect (531, 404, 18, 36); //draws fourth skull's second black mouth hole
	c.fillRect (558, 404, 18, 36); //draws fourth skull's third black mouth hole

	int skullX1[] = {24, 24, 96, 96, 108, 108, 120, 120, 96, 96, 24, 24, 0, 0, 12, 12}; //array containing x-coordinates for small skulls
	int skullY1[] = {12, 0, 0, 12, 12, 24, 24, 72, 72, 120, 120, 72, 72, 24, 24, 12}; //array containing y-coordinates for small skulls

	//Second Skull
	for (int i = 0 ; i < skullX.length ; i++) //for loop going through every value in the array
	{
	    skullX1 [i] += 197; //adds 197 to every x-coordinate in the array
	    skullY1 [i] += 320; //adds 320 to every y-coordinate in the array
	} //closes for loop
	c.drawPolygon (skullX1, skullY1, 16); //draws second skull outline
	c.fillRect (221, 356, 24, 24); //draws big part of second skull's left eye
	c.fillRect (269, 356, 24, 24); //draws big part of second skull's right eye
	c.fillRect (209, 368, 12, 12); //draws small part of second skull's left eye
	c.fillRect (293, 368, 12, 12); //draws small part of second skull's right eye
	c.fillRect (233, 416, 12, 24); //draws second skull's first black mouth hole
	c.fillRect (251, 416, 12, 24); //draws second skull's second black mouth hole
	c.fillRect (269, 416, 12, 24); //draws second skull's third black mouth hole

	//Third Skull
	for (int i = 0 ; i < skullX.length ; i++) //for loop going through every value in the array
	{
	    skullX1 [i] += 125; //adds 125 to every x-coordinate in the array
	} //closes for loop
	c.drawPolygon (skullX1, skullY1, 16);
	c.fillRect (346, 356, 24, 24); //draws big part of third skull's left eye
	c.fillRect (394, 356, 24, 24); //draws big part of third skull's right eye
	c.fillRect (334, 368, 12, 12); //draws small part of third skull's left eye
	c.fillRect (418, 368, 12, 12); //draws small part of third skull's right eye
	c.fillRect (358, 416, 12, 24); //draws third skull's first black mouth hole
	c.fillRect (376, 416, 12, 24); //draws third skull's second black mouth hole
	c.fillRect (394, 416, 12, 24); //draws third skull's third black mouth hole


	thread1.stop (); // Stop the thread

	c.setFont (new Font ("Sitka Text", 0, 17)); // Draws "Press any key to continue" text
	c.drawString ("Press any key to continue", 225, 280);

	// Wait for user input and return from the method
	c.getChar (); // Wait for user input
	return; // Return from the method


    }


    /*
    This method provides different collision checks for blocks
    based on the current game level (Bottom set of blocks). The
    method returns true if a collision is detected and false
    otherwise

    No local variables used.

    Credits: Jonathan Ye

    *This is actually overloaded to allow for the checking of both
    the current block and the next block. This is a black box
    return method.
    */

    private boolean checkBlock ()
    {
	/*
	This switch statement determines if the user is on the correct block.
	It starts by getting the current answer (answer for the bottom set)
	and then goes to that block. If the user is on that block, it will
	return true. Otherwise, it will return false.
	*/
	switch (multipleChoices [gameLevel % 25]) //Get current answer
	{
	    case 1: //case 1
		return (xy [0] > 66 && xy [0] < 146); //checks if the character is in range of block 1
	    case 2: //case 2
		return (xy [0] > 212 && xy [0] < 292);  //checks if the character is in range of block 2
	    case 3: //case 3
		return ((xy [0] > 212 + 146 && xy [0] < 292 + 146));  //checks if the character is in range of block 3
	    case 4: //case 4
		return (xy [0] > 212 + 146 + 146 && xy [0] < 292 + 146 + 146);  //checks if the character is in range of block 4
	}
	return false; //return false otherwise
    }


    /*
    This method provides different collision checks for blocks
    based on the next game level (Top set of blocks). The
    method returns true if a collision is detected and false
    otherwise

    No local variables used.

    Credits: Jonathan Ye

    *This is actually overloaded to allow for the checking of both
    the current block and the next block. This is a black box
    return method.
    */
    private boolean checkBlock (boolean next)
    {
	/*
	This switch statement determines if the user is on the correct block.
	It starts by getting the next answer (answer for the top set)
	and then goes to that block. If the user is on that block, it will
	return true. Otherwise, it will return false.
	*/
	switch (multipleChoices [(gameLevel + 1) % 25]) //Get next answer
	{
	    case 1: //case 1
		return (xy [0] > 66 && xy [0] < 146); //checks if the character is in range of block 1
	    case 2: //case 2
		return (xy [0] > 212 && xy [0] < 292);  //checks if the character is in range of block 2
	    case 3: //case 3
		return ((xy [0] > 212 + 146 && xy [0] < 292 + 146));  //checks if the character is in range of block 3
	    case 4: //case 4
		return (xy [0] > 212 + 146 + 146 && xy [0] < 292 + 146 + 146);  //checks if the character is in range of block 4
	}
	return false; //return false otherwise
    }


    /*
    Draws the game question on the screen with a colored background and formatted text.
    No local variables
     */
    private void drawGameQuestion ()
    {
	// reset the background color + clear previous question
	c.setColour (oakBrown);
	c.fillRect (100, 50, 450, 100);

	c.setColour (Color.WHITE); //set colour
	c.setFont (new Font ("Sitka Text", Font.BOLD, 12)); //set font

	c.drawString (questions [gameLevel % 25], 110, 70); //draws question

	c.setFont (new Font ("Sitka Text", Font.BOLD, 11)); //set smaller font for answers

	// Draw the four answer options at specified locations
	c.drawString (answers [gameLevel % 25] [0], 110, 110); // Option A
	c.drawString (answers [gameLevel % 25] [1], 335, 110); // Option B
	c.drawString (answers [gameLevel % 25] [2], 110, 130); // Option C
	c.drawString (answers [gameLevel % 25] [3], 335, 130); // Option D
    }



    /*
    Local Variables:
    name    datatype    use
    x       int         represents x value of cloud
    y       int         represents y value of cloud
    Method description: This private method, gameBackground(), is responsible for
			drawing the background elements of the game. It includes
			a light blue sky, a yellow sun, fluffy white clouds, a
			question sign with an oak brown background, a sign hanger
			with dark brown supports, and a strip of lava at the bottom
			with a red color where the user may die.
    Credits: Jonathan Ye
    */
    private void gameBackground ()
    {
	//Variable declaration
	int x;
	int y;

	//SKY
	c.setColor (lightBlue); //set color to light blue
	c.fillRect (0, 0, 650, 470); //draw sky background

	//SUN
	c.setColor (Color.YELLOW); //Set color to yellow
	c.fillOval (0, 0, 60, 60); //draw sun

	//CLOUDS
	c.setColor (Color.WHITE); //Set color to white

	//Cloud 1
	x = 20; //location x
	y = 100; //location y
	c.fillOval (x - 20, y, 40, 40); //circle 1
	c.fillOval (x, y - 10, 50, 50); //circle 2
	c.fillOval (x + 30, y, 40, 40); //circle 3

	//Cloud 2
	x = 100; //location x
	y = 8; //location y
	c.fillOval (x - 20, y, 40, 40); //circle 1
	c.fillOval (x, y - 10, 50, 50); //circle 2
	c.fillOval (x + 30, y, 40, 40); //circle 3

	//Cloud 3
	x = 400; //location x
	y = 100; //location y
	c.fillOval (x - 20, y, 40, 40); //circle 1
	c.fillOval (x, y - 10, 50, 50); //circle 2
	c.fillOval (x + 30, y, 40, 40); //circle 3

	//Cloud 4
	x = 300; //location x
	y = 20; //location y
	c.fillOval (x - 20, y, 40, 40); //circle 1
	c.fillOval (x, y - 10, 50, 50); //circle 2
	c.fillOval (x + 30, y, 40, 40); //circle 3

	//Cloud 5
	x = 500; //location x
	y = 8; //location y
	c.fillOval (x - 20, y, 40, 40); //circle 1
	c.fillOval (x, y - 10, 50, 50); //circle 2
	c.fillOval (x + 30, y, 40, 40); //circle 3

	//Cloud 6
	x = 600; //location x
	y = 100; //location y
	c.fillOval (x - 20, y, 40, 40); //circle 1
	c.fillOval (x, y - 10, 50, 50); //circle 2
	c.fillOval (x + 30, y, 40, 40); //circle 3



	//QUESTION SIGN
	c.setColor (oakBrown); //Set color to oak brown
	c.fillRect (100, 50, 450, 100);

	//SIGN HANGER
	c.setColor (darkBrown); //Set color to dark brown
	c.drawLine (0, 0, 100, 50);
	c.drawLine (640, 0, 550, 50);

	//LAVA
	c.setColor (Color.RED); //Set color to red
	c.fillRect (0, 470, 650, 50);
	
	for(int i = 0; i<50; i++){
	    c.setColor(new Color (255, 255-(i+70)*2, 0));
	    c.drawLine(0, i+470, 650, i+470);
	}

	//Title
	c.setFont (new Font ("Sitka Text", Font.BOLD, 20)); //set font

	//White text to give glow feeling
	c.setColor (Color.WHITE);
	c.drawString ("Indigenous Culture Awareness Game", 146, 30);
	c.drawString ("Indigenous Culture Awareness Game", 145, 31);
	c.drawString ("Indigenous Culture Awareness Game", 145, 29);
	c.drawString ("Indigenous Culture Awareness Game", 144, 30);

	c.setColor (Color.BLACK); //set color to black
	c.drawString ("Indigenous Culture Awareness Game", 145, 30);
    }
}

/*
The "CheckKey" class extends Thread and handles keyboard input. It tracks
arrow key presses ('A' and 'D') to adjust the x-coordinate of a point in
the xy array. Additionally, it responds to the space/'W' when specific
conditions are met, setting a velocity variable to 10. The thread runs
indefinitely, continuously checking for user input.

This works and does not pause the entire animation as it is a thread and
is aside from the main game.

Global Variables:
Variable Name |    Type     | Function
-----------------------------------
   a          |  Console    | Reference to the console for input/output
   key        |    char     | Stores the latest keyboard input character
   vel        |   double    | Velocity variable, used when space key is pressed
   xy         |    int[]    | Array holding x and y coordinates of a point
*/
class CheckKey extends Thread
{
    //Variable declaration section
    Console a;
    char key;
    double vel = 0;
    int[] xy;

    public CheckKey (Console c, int[] xyval)  //Class setup method
    {
	a = c; //Sets console to be console from parameter
	xy = xyval; //Sets the xy array from parameter
    }


    public void run ()
    {
	/*
	The while loop runs indefinitely to continuously monitor keyboard
	input. Inside the loop, the key variable is updated with the
	latest char input from the console.

	The loop then checks the value of key to perform different actions:
	1. If the key is 'd' or 'D', it increments x in the xy array by 5 units
	2. If the key is 'a' or 'A', it decrements x in the xy array by 5 units
	3. If the key is ' ' or 'W' or 'w', and the character is on a block, it sets the vel variable to 10

	The loop then repeats, continuously checking for new keyboard input
	and adjusting the variables accordingly.
	*/
	while (true)
	{
	    key = a.getChar (); //gets keyboard input
	    if ((key == 'd' || key == 'D')) //checks for d
	    {
		xy [0] += 5; //increments x
	    }

	    else if ((key == 'a' || key == 'A')) //checks for d
	    {
		xy [0] -= 5; //decrements x

	    }
	    else if ((key == ' ' || key == 'W' || key == 'w') && ((xy [0] > 66 && xy [0] < 146)
			|| (xy [0] > 212 && xy [0] < 292)
			|| ((xy [0] > 212 + 146 && xy [0] < 292 + 146))
			|| (xy [0] > 212 + 146 + 146 && xy [0] < 292 + 146 + 146)) && xy [1] <= 10) //checks for being on the block and ' ' or w
	    {
		vel = 10; //sets velocity to 10 for gravity
	    }

	}
    }
}
