/*
Name: Raquel Canto and Jonathan Ye
Submission Date: January 15, 2023
Teacher: Ms. Krasteva
Program Description: This program will take the user through an animated introduction, a maze of learning, and a which will educate them on Indigenous Culture and later test their knowledge. The program will
		     teach the user about the Indigenous Creation Story, Tricksters, Transformers, Shamans, and Guardian Spirits (and Quests). The program will also provide instructions on the program
		     if the user decides that they would like further insight on the program's content. This program will also save the user's high scores for the game of testing.

		     USER NOTE: Credits of who completed the code in each method can be found in the method description commented above each method (after local variables table).
		     This is the Main Class.

	     Global Variables

  Variable Name |  Type  | Function
 -----------------------------------
  menuChoice    | int     | stores the value that the user enters in main menu to determine if they will continue to the animated introduction, maze of learning, game of testing, instructions, high scores, or goodbye screen.
  name          | String  | stores the String value that the user inputted as their name or pseudonym
  mazeQuestion  | int     | stores the number of the question the user is currently on in the maze
  mazeChoice    | int     | stores the user input entered in the maze to select which of the multiple choice is the correct answer
  mazeScore     | int     | stores the users final score (how many questions they got correct) in the maze
  personX       | int     | stores the x-coordinate of the character in the maze
  personY       | int     | stores the y-coordinate of the character in the maze
  turtleX       | int     | stores the x-coordinate of the animated turtle in the animated introduction
  tricksterX    | int     | stores the x-coordinate of the trickster in the animated introduction
  fishX         | int     | stores the x-coordinate of the fish in the animated introduction
  c             | Console | creates new instance of Console for use by the class
  names         | String[]| an array storing all the names previously entered to save to the HighScores file
  scores        | int[]   | an array storing all the scores previously scored to save to the HighScores file
  lightYellow   | Color   | Represents the color (255, 238, 177)
  peach         | Color   | Represents the color (241, 222, 205)
  oakBrown      | Color   | Represents the color (171, 142, 56)
  lightGrey     | Color   | Represents the color (166, 166, 166)
  dullGreen     | Color   | Represents the color (119, 162, 144)
  lightBlue     | Color   | Represents the color (106, 184, 242)
  mediumGrey    | Color   | Represents the color (116, 116, 116)
  darkGrey      | Color   | Represents the color (84, 84, 84)
  darkBrown     | Color   | Represents the color (90, 66, 63)
  brightBlue    | Color   | Represents the color (46, 133, 198)
  brightGreen   | Color   | Represents the color (0, 193, 128)
  darkGreen     | Color   | Represents the color (0, 99, 66)
  nightSky      | Color   | Represents the color (0, 67, 137)
  magenta       | Color   | Represents the color (202, 0, 185)
  lightPink     | Color   | Represents the color (255, 163, 198)
  darkRed       | Color   | Represents the color (105, 0, 26)
  lime          | Color   | Represents the color (0, 223, 70)
  pinkPeach     | Color   | Represents the color (255, 210, 195)
  orange        | Color   | Represents the color (255, 153, 0)
  yellow        | Color   | Represents the color (255, 255, 0)


*/

import hsa.*;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*; //imports imput/output library for handling file input/output
import javax.imageio.ImageIO; //imports class to read from or write to images
import java.util.*;

class IndigenousCultureJourney
{
    int menuChoice = 0; //stores the value that the user enters in main menu determining which screen they would like to continue to
    String name; //stores the String value that the user inputted as their name or pseudonym
    int mazeQuestion; // stores the number of the question the user is currently on in the maze
    int mazeChoice; //stores the user input entered in the maze to select which of the multiple choice is the correct answer
    int mazeScore; // stores the users final score (how many questions they got correct) in the maze
    int personX; // stores the x-coordinate of the character in the maze
    int personY; // stores the y-coordinate of the character in the maze
    int turtleX = 640; // stores the x-coordinate of the animated turtle in the animated introduction
    int tricksterX = 180; // stores the x-coordinate of the trickster in the animated introduction
    int fishX = 640; // stores the x-coordinate of the fish in the animated introduction
    Console c; // creates new instance of Console for use by the class
    String[] names = new String [10]; //an array storing all the names previously entered to save to the HighScores file
    int[] scores = new int [10]; //an array storing all the scores previously scored to save to the HighScores file

    //Colour Variables
    Color lightYellow = new Color (255, 238, 177); //light yellow colour used for sun, stars, and game platforms
    Color peach = new Color (241, 222, 205); //peach colour used for classroom background wall and game platforms
    Color oakBrown = new Color (171, 142, 56); //oak brown colour used for the wooden part of the classroom chalkboard and game platforms
    Color lightGrey = new Color (166, 166, 166); //light grey colour used for the metal part of the classroom chalkboard, rocks, and game platforms
    Color dullGreen = new Color (119, 162, 144); //dull green colour used for tex boxes and game platforms
    Color lightBlue = new Color (106, 184, 242); //light blue colour used for game platforms
    Color mediumGrey = new Color (116, 116, 116); //medium grey colour used for rocks and game platforms
    Color darkGrey = new Color (84, 84, 84); //dark grey colour used for rocks and game platforms
    Color darkBrown = new Color (90, 66, 63); //dark brown colour used for classroom background floor, tree, and game platforms
    Color brightBlue = new Color (46, 133, 198); //bright blue colour used for water, maze qustion box, and game platforms
    Color brightGreen = new Color (0, 193, 128); //bright green colour used for chalkboard, correct maze answers, and game platforms
    Color darkGreen = new Color (0, 99, 66); //dark green colour used for grass and game platforms
    Color nightSky = new Color (0, 67, 137); //dark blue colour used for night sky, maze question box background, and game platforms
    Color magenta = new Color (202, 0, 185); //magenta colour used for game platforms
    Color lightPink = new Color (255, 163, 198); //light pink colour used for game platforms
    Color darkRed = new Color (105, 0, 26); //dark red colour used for game platforms
    Color lime = new Color (0, 223, 70); //lime colour used for game platforms
    Color pinkPeach = new Color (255, 210, 195); //pinkish peach colour used for game platforms
    Color orange = new Color (255, 153, 0); //custom orange colour used for maze checkpoints and game platforms
    Color yellow = new Color (255, 255, 0); //medium yellow colour used for game platforms

    public IndigenousCultureJourney ()
    {
	c = new Console ("Indigenous Culture Journey"); // creates new instance of Console for use by the class
    }


    /*
	 splashScreen() Local Variables

	 Variable Name |  Type         | Function
	------------------------------------------------
	 teacherImage |  BufferedImage | reads image from file containing drawing of teacher "Ms. Canto"

	 Method Description: The public splashScreen() method with no return value calls the private classBackground() method which draws the walls, floor, and chalkboard. Next, the method draws the title of the program, "Indigenous
			     Culture Learning Journey". Then, the method will important the image of Ms. Canto, the teacher, and animate her so she appears to be walking into her classroom. Lastly, when Ms. Canto is done walking into
			     her class, a message reading "Press any key to continue: " will appear and the user must input any character.
	 Credits: Raquel created this method.
    */

    public void splashScreen ()
    {
	classBackground (); //calls private method drawing the classroom background
	c.setFont (new Font ("Sitka Text", Font.ITALIC, 30)); //sets the font and font size
	c.setColor (darkBrown); //sets colour to dark brown
	c.drawString ("Indigenous Culture", 93, 43); //creates a shadow effect for the first line of the program title
	c.drawString ("Learning Journey", 108, 73); //creates a shadow effect for the second line of the program title
	c.setColor (Color.WHITE); //sets colour to white
	c.drawString ("Indigenous Culture", 90, 40); //draws the first line of the program title
	c.drawString ("Learning Journey", 105, 70); //draws the second line of the program title

	try
	{
	    BufferedImage teacherImage = ImageIO.read (new File ("TeacherImageISP.png")); // imports image of teacher "Ms. Canto"
	    for (int i = 500 ; i >= 400 ; i -= 3) //animates moving teacher
	    {
		c.setColor (peach); //sets colour to peach
		c.fillRect (i, 35, 185, 435); //erases image trail on wall
		c.drawImage (teacherImage, i, 32, null); //draws image of teacher multiple times to create animation effect
		try
		{
		    Thread.sleep (100); //pauses the execution to create animation effect
		}
		catch (Exception e)  // handles any exceptions that might occur during the thread sleep
		{
		}
	    } //closes for loop
	}
	catch (IOException e)  // handles IOException, for example, if the image file is not found
	{
	}

	c.setColour (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.ITALIC, 15)); //sets the font and font size
	c.drawString ("Press any key to continue", 5, 490); //draws string asking for user input
	c.getChar (); //reads user input
    } //closes public splashScreen() method


    /*
      title() Local Variables = N/A
      Method Description: The private title() method with no return prints the centered game title when called.
      Credits: Jonathan created this method.
    */
    private void title ()
    {
	c.clear (); //clears screen
	c.print ("\n", 40 - "Indigenous Culture Journey".length () / 2); //centers title
	c.println ("Indigenous Culture Journey\n"); //prints title
    } //closes private title() method


    /*
       askData() Local Variables = N/A
       Method Description: The public askData() method with no return value calls the private title() method to draw the title at the top of the screen. Next, it calls the private flowers() method to draw flowers in the corner
			   of the screen. The method then asks for the user to input their name or pseudonym and will error trap empty input.
       Credits: Raquel created this method.
    */
    public void askData ()
    {
	title (); //calls private method that draws title
	flowers (); //calls private method that draws flowers
	c.print ("Hello User! Please enter your name or pseudonym: "); //asks user to input their name or pseudonym
	while (true)
	{
	    try
	    {
		c.setCursor (4, 50); //sets cursor to proper location
		name = c.readLine (); //reads user input
		if (name.length () == 0) //if user input is empty
		{
		    throw new ArithmeticException (); //throws an exception
		}
	    }
	    catch (ArithmeticException e)
	    {
		new Message ("You have not entered anything. Please enter your name or pseudonym"); //causes error message to pop up when the user input is empty
		continue; //continues in while loop
	    }
	    break; //exits while loop
	} //closes while loop
    } //closes public askData() method


    /*
	   mainMenu() Local Variables = N/A
	   Method Description: The public mainMenu() method with no return value calls the private title() method to draw the title at the top of the screen. Next, it greets the user and refers to them by their previously entered name or
			       pseudonym. It will then display all the main menu options the user has. The user must decide which screen to continue to. The user input for the menu selection has been errortrapped.
	   Credits: Jonathan created this method.
    */
    public void mainMenu ()
    {
	title (); //calls private method that draws title
	c.println ("Hello " + name + "! Welcome to Indigenous Culture Journey! \n"); //prints message welcoming user to the program
	c.println ("Please select one of the options:"); //asks user to select one of the following menu options to decide which screen to continue to
	c.println ("  1. Level 1: Animated Introductions"); //prints first option: continue to the animated introduction
	c.println ("  2. Level 2: Maze of Learning"); //prints second option: continue to the maze of learning
	c.println ("  3. Level 3: Game of Testing"); //prints the third option: continue to the game of testing
	c.println ("  4. Instructions"); //prints the fourth option: continue to the instructions
	c.println ("  5. High Scores"); //prints the fifth option: continue to high scores
	c.println ("  6. Exit\n"); //prints the sixth option: continue to goodbye screen
	c.print ("Enter your choice: "); //asks user to input their choice

	while (true)
	{
	    c.setCursor (14, 20); //sets cursor to proper location
	    c.println ("\n\n\n\n"); //erases any input if necessary
	    c.setCursor (14, 20); //sets cursor to proper location
	    try
	    {
		menuChoice = Integer.parseInt (c.readLine ()); // read user input
		if (menuChoice < 1 || menuChoice > 6) //if input is not an integer from 1 to 6
		{
		    throw new ArithmeticException (); //throws an exception
		}
	    }
	    catch (NumberFormatException e)
	    {
		new Message ("Enter an integer!", "Error"); //causes an error message to pop up when the user enters a character that is not an integer
		continue; //continues in loop
	    }
	    catch (ArithmeticException e)
	    {
		new Message ("The integer should be from 1 to 6!", "Error"); //causes an error message to pop up when the user enters an integer that is not a value from 1 to 6
		continue; //continues in loop
	    }
	    break; //exits loop
	} //closes while loop
    } //closes public mainMenu() method


    /*
	   turtleLeft() Local Variables

	    Variable Name |  Type         | Function
	  ----------------------------------------------
	    turtleImage   |  BufferedImage| reads image from file containing drawing of turtle

	   Method Description: The private turtleLeft() method with no return value reads from the file containing the image of the turtle featured in the creation
			       story that will later be drawn and animated.
	   Credits: Raquel created this method.
    */
    private void turtleLeft ()
    {
	try
	{ // imports image
	    BufferedImage turtleImage = ImageIO.read (new File ("NewTurtleISP.png")); //reads from file containing image of turtle featured in the creation story
	    for (int i = turtleX ; i >= 200 ; i -= 2) //for loop animates turtle
	    {
		c.setColor (nightSky); //sets colour to dark blue
		// draw the background ovals to erase the turtle's trail
		c.fillOval (70 + i - 1, 150, 170, 130);
		c.fillOval (5 + i - 1, 220, 72, 72);
		c.fillOval (i + 60 - 1, 205, 220, 130);
		c.fillOval (i + 60 - 1, 300, 100, 50);
		c.fillOval (i + 170 - 1, 300, 75, 50);
		c.drawImage (turtleImage, i, 150, null);
		try
		{
		    Thread.sleep (50); //pauses the execution to create animation effect
		}
		catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		{
		}
	    } //closes for loop
	}
	catch (IOException e)  //handles IOException
	{
	}
    } //closes private turtleLeft() method


    /*
	     animatedIntroduction() Local Variables

	     Variable Name      |  Type         | Function
	    ------------------------------------------------
	     creationTexts[]    | String        | an array strong each line of typewriter style test teacher the user about the creation story
	     creationChangeY    | int           | stores the starting y-coordinate and the value in between each line of text in the creation story lesson
	     creationLine       | String        | a temporary variable storing one line of the creationTexts[] array at a time
	     trickster          | BufferedReader| reads image from file containing drawing of trickster
	     tricksterTexts[]   | String        | an array strong each line of typewriter style test teacher the user about tricksters
	     tricksterChangeY   | int           | stores the starting y-coordinate and the value in between each line of text in the trickster lesson
	     tricksterLine      | String        | a temporary variable storing one line of the tricksterTexts[] array at a time
	     transformer        | BufferedReader| reads image from file containing drawing of transformer
	     transformerTexts[] | String        | an array strong each line of typewriter style test teacher the user about transformers
	     transformerChangeY | int           | stores the starting y-coordinate and the value in between each line of text in the transformer lesson
	     transformerLine    | String        | a temporary variable storing one line of the transformerTexts[] array at a time
	     shamansTexts[]     | String        | an array strong each line of typewriter style test teacher the user about shamans
	     shamanChangeY      | int           | stores the starting y-coordinate and the value in between each line of text in the shaman lesson
	     shamanLine         | String        | a temporary variable storing one line of the shamansTexts[] array at a time
	     standingMan        | BufferedReader| reads image from file containing drawing of standing man waiting for guardian spirit encounter
	     riverTexts[]       | String        | an array strong each line of typewriter style test teacher the user about guardian spirits
	     riverLine          | String        | a temporary variable storing one line of the riverTexts[] array at a time
	     riverChangeY       | int           | stores the starting y-coordinate and the value in between each line of text in the guardian spirit and quests lesson

	     Method Description: The public animatedIntroduction() method with no return value calls the private nightBackground() method which will draw the night sky
				 background. This method will be called multiple times in animatedIntroduction(). The method will then draw the title, read from and
				 sometimes animate the images, draw the typewriter-style text, etc. for each of the five major topics that the user will learn about in the
				 animated introduction. The users will learn about the Creation Story, Tricksters, Transformers, Shamans, and Guardian Spirits (and Quests).
	     Credits: Raquel created this method.
	*/

    public void animatedIntroduction ()
    {
	//Creation Story
	nightBackground (); //calls the private method drawing the night sky
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.BOLD, 30)); //sets the font and font size
	c.drawString ("The Creation Story", 180, 100); //centered screen title
	turtleLeft (); //calls private method drawing and animating the turtle

	//Creation Story Text
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.PLAIN, 15)); //sets the font and font size
	String[] creationTexts = {  //an array strong each line of typewriter style test teacher the user about the creation story
	    "The Indigenous creation story is about a cultural hero: the",  //line one of creationTexts[]
	    "Great Spirit. In the 'Earth Diver myth,' Spirit dives into",  //line two of creationTexts[]
	    "ancient waters to find m ud to shape the Earth. Some versions",  //line three of creationTexts[]
	    "feature the Earth on a Turtle's back, leading to N. America",  //line four of creationTexts[]
	    "being called 'Turtle Island'. Click any key to continue.",  //line five of of creationTexts[]
	    };
	int creationChangeY = 436; // initial Y-coordinate
	for (int j = 0 ; j < creationTexts.length ; j++) //reads each line of creationTexts[]
	{
	    String creationLine = creationTexts [j]; //create a new variable that will temporarily store each line of the array
	    for (int i = 0 ; i < creationLine.length () ; i++) //reads each character in whichever line of the array is currently being stored in creationLine
	    {
		c.drawString (creationLine.charAt (i) + "", i * 10 + 5, creationChangeY); //draws each character in the line of the arraythat is currently being stored in creationLine
		try
		{
		    Thread.sleep (30); //pauses the execution to create typewriter effect
		}
		catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		{
		}
	    } //closes for loop reading each character in each line
	    creationChangeY += 15; // Adjust Y-coordinate for the next line
	} //closes for loop reading each line of the array
	c.getChar (); //reads user input

	//Tricksters
	nightBackground (); //calls the private method drawing the night sky
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.BOLD, 30)); //sets the font and font size
	c.drawString ("Tricksters", 240, 100); //centered screen title

	//Extra Stars
	c.setColor (lightYellow); //sets colour to light yellow
	c.fillStar (464, 124, 20, 20);
	c.fillStar (368, 135, 20, 20);
	c.fillStar (550, 78, 20, 20);
	c.fillStar (576, 153, 20, 20);
	c.fillStar (533, 284, 20, 20);
	c.fillStar (398, 213, 20, 20);
	c.fillStar (531, 180, 20, 20);
	c.fillStar (423, 63, 20, 20);
	c.fillStar (423, 295, 20, 20);
	c.fillStar (392, 63, 20, 20);
	c.fillStar (465, 213, 20, 20);
	c.fillStar (567, 295, 20, 20);
	c.fillStar (348, 102, 20, 20);
	c.fillStar (491, 158, 20, 20);
	c.fillStar (412, 249, 20, 20);

	try
	{ // imports image
	    BufferedImage trickster = ImageIO.read (new File ("TricksterTransparentImage.png")); //reads from file containing image of trickster
	    c.drawImage (trickster, tricksterX, 100, null); //draws image of tricksters
	}
	catch (IOException e)  //handles IOException
	{
	}

	//Tricksters Text
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.PLAIN, 15)); //sets the font and font size
	String[] tricksterTexts = {  //an array strong each line of typewriter style test teacher the user about tricksters
	    "Tricksters are wise yet secretive characters in Indigenous",  //line one of tricksterTexts[]
	    "culture. They can be any gender, foolish or helpful, hero",  //line two of tricksterTexts[]
	    "or trouble, hum an, spirit, anim al, young or old, half hum an",  //line three of tricksterTexts[]
	    "and half spirit, etc. Click any key to continue.",  //line four of of tricksterTexts[]
	    };
	int tricksterChangeY = 440; // Initial Y-coordinate
	for (int j = 0 ; j < tricksterTexts.length ; j++) //reads each line of tricksterTexts[]
	{
	    String tricksterLine = tricksterTexts [j]; //create a new variable that will temporarily store each line of the array
	    for (int i = 0 ; i < tricksterLine.length () ; i++) //reads each character in whichever line of the array is currently being stored in tricksterLine
	    {
		c.drawString (tricksterLine.charAt (i) + "", i * 10 + 6, tricksterChangeY); //draws each character in the line of the arraythat is currently being stored in tricksterLine
		try
		{
		    Thread.sleep (30); //pauses the execution to create typewriter effect
		}
		catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		{
		}
	    } //closes for loop reading each character in each line
	    tricksterChangeY += 17; // Adjust Y-coordinate for the next line
	} //closes for loop reading each line of the array
	c.getChar (); //reads user input

	//Transformers
	nightBackground (); //calls the private method drawing the night sky
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.BOLD, 30)); //sets the font and font size
	c.drawString ("Transformers", 215, 100); //draws centered titled

	//Extra Stars
	c.setColor (lightYellow); //sets colour to ligh yellow
	c.fillStar (464, 124, 20, 20);
	c.fillStar (368, 135, 20, 20);
	c.fillStar (550, 78, 20, 20);
	c.fillStar (576, 153, 20, 20);
	c.fillStar (533, 284, 20, 20);
	c.fillStar (398, 213, 20, 20);
	c.fillStar (531, 180, 20, 20);
	c.fillStar (423, 63, 20, 20);
	c.fillStar (423, 295, 20, 20);
	c.fillStar (392, 63, 20, 20);
	c.fillStar (465, 213, 20, 20);
	c.fillStar (567, 295, 20, 20);
	c.fillStar (348, 102, 20, 20);
	c.fillStar (491, 158, 20, 20);
	c.fillStar (412, 249, 20, 20);
	try
	{ // imports image
	    BufferedImage transformer = ImageIO.read (new File ("CrowImageISP.png")); //reads from file containing image of transformer
	    c.drawImage (transformer, 160, 120, null); //draws image of transformer
	}
	catch (IOException e)  //handles IOException
	{
	}

	//Transformers Text
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.PLAIN, 15)); //sets the font and font size
	String[] transformerTexts = {  //an array strong each line of typewriter style test teacher the user about transformers
	    "According to Indigenous beliefs, Transform ers (shape-shifters)",  //line one of transformerTexts[]
	    "are beings that can change shape from their original, hum an,",  //line two of transformerTexts[]
	    "form into an anim al or non-living object. Click any key",  //line three of transformerTexts[]
	    "to continue.",  //line four of transformerTexts[]
	    };
	int transformerChangeY = 440; // Initial Y-coordinate
	for (int j = 0 ; j < transformerTexts.length ; j++) //reads each line of transformerTexts[]
	{
	    String transformerLine = transformerTexts [j]; //create a new variable that will temporarily store each line of the array
	    for (int i = 0 ; i < transformerLine.length () ; i++) //reads each character in whichever line of the array is currently being stored in transformerLine
	    {
		c.drawString (transformerLine.charAt (i) + "", i * 10 + 5, transformerChangeY); //draws each character in the line of the arraythat is currently being stored in transformerLine
		try
		{
		    Thread.sleep (30); //pauses the execution to create typewriter effect
		}
		catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		{
		}
	    } //closes for loop reading each character in each line
	    transformerChangeY += 17; // Adjust Y-coordinate for the next line
	} //closes for loop reading each line of the array
	c.getChar (); //reads user input

	//Shamans
	nightBackground (); //calls the private method drawing the night sky
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.BOLD, 30)); //sets the font and font size
	c.drawString ("Shamans", 250, 100); //centered screen title
	shamanHeal (); //calls private method that draws shaman

	//Extra Stars
	c.setColor (lightYellow); //sets colour to light yellow
	c.fillStar (464, 124, 20, 20);
	c.fillStar (368, 135, 20, 20);
	c.fillStar (550, 78, 20, 20);
	c.fillStar (576, 153, 20, 20);
	c.fillStar (533, 284, 20, 20);
	c.fillStar (398, 213, 20, 20);
	c.fillStar (531, 180, 20, 20);
	c.fillStar (423, 63, 20, 20);
	c.fillStar (423, 295, 20, 20);
	c.fillStar (392, 63, 20, 20);
	c.fillStar (465, 213, 20, 20);
	c.fillStar (567, 295, 20, 20);
	c.fillStar (348, 102, 20, 20);
	c.fillStar (491, 158, 20, 20);
	c.fillStar (412, 249, 20, 20);

	//Shamans Text
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.PLAIN, 15)); //sets the font and font size
	String[] shamansTexts = {  //an array strong each line of typewriter style test teacher the user about shamans
	    "In Indigenous cultures, sham ans play crucial roles as healers,",  //line one of shamanTexts[]
	    "prophets, and guardians. They lead cerem onies, have powers",  //line two of shamanTexts[]
	    "for the com m unity's well-being, and predict hunts, finding",  //line three of shamanTexts[]
	    "lost things, and addressing illnesses or com m unal issues.",  //line four of shamanTexts[]
	    "Click any key to continue." //line five of shamanTexts[]
	    };
	int shamanChangeY = 436; // Initial Y-coordinate
	for (int j = 0 ; j < shamansTexts.length ; j++) //reads each line of shamansTexts[]
	{
	    String shamanLine = shamansTexts [j]; //create a new variable that will temporarily store each line of the array
	    for (int i = 0 ; i < shamanLine.length () ; i++) //reads each character in whichever line of the array is currently being stored in shamanLine
	    {
		c.drawString (shamanLine.charAt (i) + "", i * 10 + 5, shamanChangeY); //draws each character in the line of the arraythat is currently being stored in shamanLine
		try
		{
		    Thread.sleep (30); //pauses the execution to create typewriter effect
		}
		catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		{
		}
	    } //closes for loop reading each character in each line
	    shamanChangeY += 15; // Adjust Y-coordinate for the next line
	} //closes for loop reading each line of the array
	c.getChar (); //reads user input


	//Guardian Spirit
	riverBackground (); //calls the private method drawing the river background
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.BOLD, 30)); //sets the font and font size
	c.drawString ("Guardian Spirits and Quests", 110, 100); //centered screen title
	try
	{ // imports image
	    BufferedImage standingMan = ImageIO.read (new File ("StandingManImage.png")); //reads from file containing image of standing man awaiting an encounter with a guardian spirit
	    c.drawImage (standingMan, 210, 210, null); //draws image of standing man awaiting encounter
	}
	catch (IOException e)  //handles IOException
	{
	}
	guardianLeft (); //calls private method that draws and animates guardian spirit

	//Guardian Spirit Text
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.PLAIN, 15)); //sets the font and font size
	String[] riverTexts = {  //an array strong each line of typewriter style test teacher the user about guardian spirits and quests
	    "During puberty, boys stay in rem ote areas for long periods,",  //line one of riverTexts[]
	    "fasting, praying, and purifying in bodies of water. They seek a",  //line two of riverTexts[]
	    "vision or encounter with a guardian spirit, often anim al or",  //line three of riverTexts[]
	    "m ythical, who would ensure health and success in hunting",  //line four of riverTexts[]
	    "and fishing. Click any key to continue." //line five of riverTexts[]
	    };
	int riverChangeY = 436; // Initial Y-coordinate
	for (int j = 0 ; j < riverTexts.length ; j++) //reads each line of riverTexts[]
	{
	    String riverLine = riverTexts [j]; //create a new variable that will temporarily store each line of the array
	    for (int i = 0 ; i < riverLine.length () ; i++) //reads each character in whichever line of the array is currently being stored in riverLine
	    {
		c.drawString (riverLine.charAt (i) + "", i * 10 + 5, riverChangeY); //draws each character in the line of the arraythat is currently being stored in riverLine
		try
		{
		    Thread.sleep (30); //pauses the execution to create typewriter effect
		}
		catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		{
		}
	    } //closes for loop reading each character in each line
	    riverChangeY += 15; // Adjust Y-coordinate for the next line
	} //closes for loop reading each line of the array
	c.getChar (); //reads user input
    } //closes public animatedIntroduction() method


    /*
	 shamanHeal() Local Variables

	 Variable Name      |  Type          | Function
	 ------------------------------------------------
	 hurtMan            | BufferedReader | reads image from file containing drawing of the hurt man

	 Method Description: The private shamanHeal() method with no return value reads from the file containing the drawing of the hurt man. It then draws the image. This
			     image will be used using the shaman lesson in the public animatedIntroduction() method.
	 Credits: Raquel created this method.
    */
    private void shamanHeal ()
    {
	try
	{ // imports image
	    BufferedImage hurtMan = ImageIO.read (new File ("HurtManImage.png")); //reads from file containing image of the hurt man
	    c.drawImage (hurtMan, 250, 100, null); //draws the image of the hurt man
	}
	catch (IOException e)  //handles IOException
	{
	}
    } //closes private shamanHeal() method


    /*
	guardianLeft() Local Variables

	Variable Name      |  Type          | Function
	------------------------------------------------
	fish            | BufferedReader | reads image from file containing drawing of the hurt man

	Method Description: The private guardianLeft() method with no return value reads from the file containing the drawing of the fish. It then draws the image. This
			    image will be used using the guardian spirit and quests lesson in the public animatedIntroduction() method.
	Credits: Raquel created this method.
    */
    private void guardianLeft ()
    {
	try
	{ // imports image
	    BufferedImage fish = ImageIO.read (new File ("NewTransparentFish.png")); //reads from file containing image of he guardian spirit (fish)
	    for (int i = fishX ; i >= 270 ; i--) //animates guardian spirit (fish)
	    {
		c.setColor (brightBlue); //sets colour to bright blue
		c.fillOval (i + 9, 365, 70, 45); //draws an oval to erase the trail of the animated fish
		c.drawImage (fish, i, 360, null); //draws fish image multiple times to create animation effect
		try
		{
		    Thread.sleep (20); //pauses the execution to create animation effect
		}
		catch (InterruptedException e)  //handles any exceptions that might occur during the thread sleep
		{
		}
	    } //closes for loop
	}
	catch (IOException e)  //handles IOException
	{
	}
    } //closes private guardianLeft() method


    /*
	    mazeOfLearning() Local Variables = N/A
	    Method Description: The public mazeOfLearning() method with no return value will repeatedly call the private characterAnimation() to draw and then animate the
				character that will be used throughout this maze. This method will animate the character to move until it reaches various checkpoints in
				the maze. Once it reaches the checkpoints just mentioned, it will call the private mazeQuestion() method to draw the question box and print
				the question (and the multiple choice answers) corresponding to the checkpoint that the user is trying to reach. If the user entered the
				correct answer, the checkpoint will light up green and then erase. If the user entered the wrong answer, the checkpoint will light up red
				then erase. Lastly, the method will display, in the question box, how many of the maze questions (out of 8) the user answered correctly.
	    Credits: Raquel created this method.
	*/
    public void mazeOfLearning ()
    {
	mazeQuestion = 1; //resets mazeQuestion variable
	mazeScore = 0; //resets mazeScore variable
	personX = 55; //resets personX variable to starting x-coordinate
	personY = 55; //resets personY variable to starting y-coordinate
	mazeBackground (); //calls private method drawing maze background

	//Draws Checkpoints
	c.setColor (orange); //sets colour to orange
	c.fillOval (35, 170, 40, 40); //draws first checkpoint
	c.fillOval (210, 420, 40, 40); //draws second checkpoint
	c.fillOval (270, 230, 40, 40); //draws third checkpoint
	c.fillOval (330, 230, 40, 40); //draws fourth checkpoint
	c.fillOval (450, 370, 40, 40); //draws fifth checkpoint
	c.fillOval (450, 310, 40, 40); //draws sixth checkpoint
	c.fillOval (390, 50, 40, 40); //draws seventh checkpoint
	c.fillOval (510, 120, 40, 40); //draws eight checkpoint

	while (mazeQuestion <= 8) //while the maze questions are still being run
	{
	    if (mazeQuestion == 1) //if the user is on the first maze question
	    {
		while (personY != 120) //until character has reach the y-coordinate 120
		{
		    characterAnimation (); //draws character
		    personY++; //moves character down
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }

		} //closes while loop moving character down
		mazeQuestion (); //calls private mazeQuestion class which would draw the first question and its options
		if (mazeChoice == 2) //if the user chooses the correct choice in the maze
		{
		    c.setColor (brightGreen); //sets colour to bright green
		    c.fillOval (35, 170, 40, 40); //redraws oval to notify the user that their answer is correct
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		    mazeScore++; //increase maze score by one
		}
		else
		{
		    c.setColor (Color.RED); //sets colour to red
		    c.fillOval (35, 170, 40, 40); //redraws oval to notify the user that their answer is incorrect
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		}
		c.setColor (Color.WHITE); //sets colour to white
		c.fillOval (35, 170, 40, 40); //erases checkpoint
		mazeQuestion++; //increases maze question by one to continue into the next else if statement
	    }
	    else if (mazeQuestion == 2) //if the user is on the second maze question
	    {
		while (personY != 430) //while the character's y-coordinate is not 430
		{
		    characterAnimation (); //draws character
		    personY++; //moves character downwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personX != 110) //while the character's x-coordinate is not 110
		{
		    characterAnimation (); //draws character
		    personX++; //moves character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personY != 240) //while the character's y-coordinate is not 240
		{
		    characterAnimation (); //draws character
		    personY--; //moves the character upwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }

		} //closes while loop
		while (personX != 230) //while the characters x-coordinate is not 230
		{
		    characterAnimation (); //draws character
		    personX++; //moves the character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personY != 380) //while the character's y-coordinate is not 380
		{
		    characterAnimation (); //draws character
		    personY++; //moves the character downwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		mazeQuestion (); //calls private mazeQuestion class which would draw the second question and it's options
		if (mazeChoice == 4) //if the user chooses the correct choice in the maze
		{
		    c.setColor (brightGreen); //sets colour to bright green
		    c.fillOval (210, 420, 40, 40); //redraws oval to notify the user that their answer is correct
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		    mazeScore++; //increase maze score by one
		}
		else //if the character selects the wrong answer
		{
		    c.setColor (Color.RED); //sets colour to red
		    c.fillOval (210, 420, 40, 40); //redraws oval to notify the user that their answer is incorrect
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		}
		c.setColor (Color.WHITE); //sets colour to white
		c.fillOval (210, 420, 40, 40); //erases checkpoint
		mazeQuestion++; //increases maze question by one to continue into the next else if statement

	    }
	    else if (mazeQuestion == 3) //if the user is on the third question
	    {
		while (personY != 430) //while the character's y-coordinate is not 430
		{
		    characterAnimation (); //draws character
		    personY++; //moves character downwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personX != 290) //while the character's x-coordinate is not 290
		{
		    characterAnimation (); //draws character
		    personX++; //moves character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personY != 280) //while the character's y-coordinate is noy 280
		{
		    characterAnimation (); //draws character
		    personY--; //moves the character upwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		mazeQuestion (); //calls private mazeQuestion class which would draw the third question and it's options
		if (mazeChoice == 1) //if the user chooses the correct choice in the maze
		{
		    c.setColor (brightGreen); //sets colour to bright green
		    c.fillOval (270, 230, 40, 40); //redraws oval to notify the user that their answer is correct
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		    mazeScore++; //increase maze score by one
		}
		else //if the character selects the wrong answer
		{
		    c.setColor (Color.RED); //sets colour to red
		    c.fillOval (270, 230, 40, 40); //redraws oval to notify the user that their answer is incorrect
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		}
		c.setColor (Color.WHITE); //sets colour to white
		c.fillOval (270, 230, 40, 40); //erases the checkpoint
		mazeQuestion++; //increases maze question by one to continue into the next else if statement
	    }
	    else if (mazeQuestion == 4) //if the user is on the fourth question on the maze
	    {
		while (personY != 235) //while the character's y-coordinate is not 235
		{
		    characterAnimation (); //draws character
		    personY--; //moves the character upwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personX != 305) //while the character's x-coordinate is not 305
		{
		    characterAnimation (); //draws character
		    personX++; //moves character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		mazeQuestion (); //calls private mazeQuestion class which would draw the fourth question and it's options
		if (mazeChoice == 2) //if the user chooses the correct choice in the maze
		{
		    c.setColor (brightGreen); //sets colour to bright green
		    c.fillOval (330, 230, 40, 40); //redraws oval to notify the user that their answer is correct
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		    mazeScore++; //increase maze score by one
		}
		else
		{
		    c.setColor (Color.RED); //sets colour to red
		    c.fillOval (330, 230, 40, 40); //redraws oval to notify the user that their answer is incorrect
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		}
		c.setColor (Color.WHITE); //sets colour to white
		c.fillOval (330, 230, 40, 40); //erases checkpoint
		mazeQuestion++; //increases maze question by one to continue into the next else if statement

	    }
	    else if (mazeQuestion == 5) //if the user in on the fifth question in the maze
	    {
		while (personX != 350) //while the character's x-coordinate is not 350
		{
		    characterAnimation (); //draws character
		    personX++; //moves the character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personY != 430) //while the character's y-coordinate is not 430
		{
		    characterAnimation (); //draws character
		    personY++; //moves the character downwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personX != 410) //while the character's x-coordinate is not 410
		{
		    characterAnimation (); //draws character
		    personX++; //moves the character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personY != 380) //while the character's y-coordinate is not 380
		{
		    characterAnimation (); //draws character
		    personY--; //moves the character upwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personX != 430) //while the character's x-coordinate is not 430
		{
		    characterAnimation (); //draws character
		    personX++; //moves the character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		mazeQuestion (); //calls private mazeQuestion class which would draw the fifth question and it's options
		if (mazeChoice == 2) //if the user chooses the correct choice in the maze
		{
		    c.setColor (brightGreen); //sets colour to bright green
		    c.fillOval (450, 370, 40, 40); //redraws oval to notify the user that their answer is correct
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		    mazeScore++; //increase maze score by one
		}
		else
		{
		    c.setColor (Color.RED); //sets colour to red
		    c.fillOval (450, 370, 40, 40); //redraws oval to notify the user that their answer is incorrect
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		}
		c.setColor (Color.WHITE); //sets colour to white
		c.fillOval (450, 370, 40, 40); //erases checkpoint
		mazeQuestion++; //increases maze question by one to continue into the next else if statement

	    }
	    else if (mazeQuestion == 6) //if the user is on the sixth question in the maze
	    {
		while (personX != 470) //while the character's x-coordinate is not 470
		{
		    characterAnimation (); //draws character
		    personX++; //moves the character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personY != 360) //while the character's y-coordinate is not 360
		{
		    characterAnimation (); //draws character
		    personY--; //moves the character upwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		mazeQuestion (); //calls private mazeQuestion class which would draw the sixth question and it's options
		if (mazeChoice == 4) //if the user chooses the correct choice in the maze
		{
		    c.setColor (brightGreen); //sets colour to bright green
		    c.fillOval (450, 310, 40, 40); //redraws oval to notify the user that their answer is correct
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		    mazeScore++; //increase maze score by one
		}
		else
		{
		    c.setColor (Color.RED); //sets colour to red
		    c.fillOval (450, 310, 40, 40); //redraws oval to notify the user that their answer is incorrect
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		}
		c.setColor (Color.WHITE); //sets colour to white
		c.fillOval (450, 310, 41, 41); //erases the checkpoint
		mazeQuestion++; //increases maze question by one to continue into the next else if statement
	    }
	    else if (mazeQuestion == 7) //if the user is on the seventh question in the maze
	    {
		while (personY != 180) //while the character's y-coordinate is not 180
		{
		    characterAnimation (); //draws character
		    personY--; //moves the character upwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)
		    {
		    }
		} //closes while loop
		while (personX != 410) //while the character's x-coordinate is not 410
		{
		    characterAnimation (); //draws character
		    personX--; //moves the character to the left
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personY != 100) //while the character's y-coordinate is not 100
		{
		    characterAnimation (); //draws character
		    personY--; //moves the character upwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		mazeQuestion (); //calls private mazeQuestion class which would draw the seventh question and it's options
		if (mazeChoice == 1) //if the user chooses the correct choice in the maze
		{
		    c.setColor (brightGreen); //sets colour to bright green
		    c.fillOval (390, 50, 40, 40); //redraws oval to notify the user that their answer is correct
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		    mazeScore++; //increase maze score by one
		}
		else
		{
		    c.setColor (Color.RED); //sets colour to red
		    c.fillOval (390, 50, 40, 40); //redraws oval to notify the user that their answer is incorrect
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		}
		c.setColor (Color.WHITE); //sets colour to white
		c.fillOval (390, 50, 41, 41); //erases checkpoint
		mazeQuestion++; //increases maze question by one to continue into the next else if statement
	    }
	    else if (mazeQuestion == 8) //if the user is on the eighth question of the game
	    {
		while (personY != 40) //while the character's y-coordinate is not 40
		{
		    characterAnimation (); //draws character
		    personY--; //moves the character upwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personX != 470) //while the character's x-coordinate is not 470
		{
		    characterAnimation (); //draws character
		    personX++; //moves the character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personY != 120) //while the character's y-coordinate is not 120
		{
		    characterAnimation (); //draws character
		    personY++; //moves the character downwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personX != 495) //while the character's y-coordinate is not 495
		{
		    characterAnimation (); //draws character
		    personX++; //moves the character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		mazeQuestion (); //calls private mazeQuestion class which would draw the eighth question and it's options
		if (mazeChoice == 3) //if the user chooses the correct choice in the maze
		{
		    c.setColor (brightGreen); //sets colour to bright green
		    c.fillOval (510, 120, 40, 40); //redraws oval to notify the user that their answer is correct
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		    mazeScore++; //increase maze score by one
		}
		else
		{
		    c.setColor (Color.RED); //sets colour to red
		    c.fillOval (510, 120, 40, 40); //redraws oval to notify the user that their answer is incorrect
		    try
		    {
			Thread.sleep (600); //pauses the execution to allow users to see whether or not their answer is correct
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		}
		c.setColor (Color.WHITE); //sets colour to white
		c.fillOval (510, 120, 41, 41); //erases checkpoint
		while (personX != 530) //while the character's x-coordinate is not 530
		{
		    characterAnimation (); //draws character
		    personX++; //moves the character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personY != 260) //while the character's y-coordinate is not 260
		{
		    characterAnimation (); //draws character
		    personY++; //moves the character downwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personX != 590) //while the character's x-coordinate is not 590
		{
		    characterAnimation (); //draws character
		    personX++; //moves the character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personY != 180) //while the character's y-coordinate is not 180
		{
		    characterAnimation (); //draws character
		    personY--; //moves the character upwards
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		while (personX != 660) //while the character's x-coordinate is not 660
		{
		    characterAnimation (); //draws character
		    personX++; //moves the character to the right
		    try
		    {
			Thread.sleep (10); //pauses the execution to create animation effect
		    }
		    catch (Exception e)  //handles any exceptions that might occur during the thread sleep
		    {
		    }
		} //closes while loop
		break; //exits while loop
	    }
	} //closes while loop


	if (mazeQuestion == 8 && personX >= 650) //if all the maze questions have been completed and the character is off the screen
	{
	    c.setColor (brightBlue); //sets colour to bright blue
	    c.fillRect (88, 40, 284, 112); //redraws text box
	    c.setColor (Color.WHITE); //sets colour to white
	    c.drawString ("You scored " + mazeScore + "/8.", 90, 75); //displays message indicating how many questions the user got correct
	    c.drawString ("Click any key to continue.", 90, 90); //asks user to enter input
	    c.getChar (); //reads user input
	}
    } //closes public mazeOfLearning method


    /*
	characterAnimation() Local Variables = N/A
	Method Description: The private characterAnimation() method with no return value draws the stick figure character that will be used to represent the user in the
			    public mazeOfLearning() method. This method will be called multiple times in the public mazeOfLearning() method.
	Credits: Raquel created this method.
    */
    private void characterAnimation ()
    {
	c.setColor (Color.WHITE); //sets colour to white
	c.fillOval (personX - 17, personY - 10, 30, 30); //erases stick-man head
	c.fillRect (personX - 1, personY + 12, 3, 14); //erases stick-man body
	c.fillRect (personX - 12, personY + 17, 24, 7); //erases stick-man arms
	c.fillRect (personX - 12, personY + 23, 24, 14); //erases stick man legs
	c.setColor (Color.BLACK); //sets colour to black
	c.fillOval (personX - 10, personY - 7, 20, 20); //draws stick-man head
	c.drawLine (personX, personY + 15, personX, personY + 25); //draws stick-man body
	c.drawLine (personX - 10, personY + 20, personX + 10, personY + 20); //draws stick-man arms
	c.drawLine (personX, personY + 25, personX - 10, personY + 35); //draws stick-man left leg
	c.drawLine (personX, personY + 25, personX + 10, personY + 35); //draws stick-man right leg
	c.setColor (Color.WHITE); //sets colour to white
	c.fillRect (350, 0, 200, 20); //erases question text

    } //closes private characterAnimation method


    /*
	mazeQuestion() Local Variables

	Variable Name |  Type         | Function
       ------------------------------------------------
	questionText  |  String[] []  | an array storing the questions and answered used in the maze of learning

	Method Description: The public mazeQuestion() method with no return value is called multiple times in the public mazeOfLearning() method to draw
			    the question box, print the question, print the multiple choice answers. This method also asks for user input to determine
			    which of the multiple choice answers the user selected. User input is error trapped in this method.
	Credits: Raquel created this method with Jonathan's help.
       */
    private void mazeQuestion ()
    {
	String[] [] questionText = {
		{"What does the Great Spirit retrieve in", "the ancient waters?", "1. sand", "2. mud", "3. rocks", "4. plants"},  // question 1: mud
		{"On which animal's back was the Earth", "said to grow on?", "1. elephant", "2. moose", "3. dog", "4. turtle"},  // question 2: turtle
		{"Which characteristic would never be", "used to describe a trickster?", "1. invisible", "2. secretive", "3. foolish", "4. young"},  // question 3: invisible
		{"What is a transformer's original form?", "1. animal", "2. human", "3. spirit", "4. non-living object"},  // question 4: human
		{"Which of the following can a Shaman", "not do?", "1. predict hunts", "2. address illnesses", "3. find lost things", "4. build homes"},  // question 5: build homes
		{"Why do boys stay in remote areas for", "long periods of time?", "1. to hunt", "2. to find a guardian spirit", "3. to explore", "4. to search for unoccupied land"},  // question 6: to search unoccupied land
		{"Which of the following do boys not do", "during their stays in remote areas?", "1. farm", "2. fast", "3. self-purify", "4. pray"},  // question 7: farm
		{"Which of the following can a Guardian", "Spirit not promise?", "1. success in hunting", "2. success in fishing", "3. fertility", "4. health"}  // question 8: fertility
	    };
	c.setColor (nightSky); //sets colour to dark blue
	c.fillRect (78, 30, 304, 132); //draws question box border
	c.setColor (brightBlue); //sets colour to bright blue
	c.fillRect (88, 40, 284, 112); //draws question box
	c.setColor (Color.WHITE); //sets colour to white
	c.setFont (new Font ("Sitka Text", Font.PLAIN, 15)); //sets the font and font size

	for (int i = 0 ; i < questionText [mazeQuestion - 1].length ; i++) //reads each question and it's answers
	{
	    c.drawString (questionText [mazeQuestion - 1] [i] + "", 90, 55 + i * 15); //draws text stored in questionText[][] array
	} //closes for loop


	c.setColor (Color.BLACK); //sets colour to black
	c.drawString ("Enter the int for the correct answer: ", 90, 15);
	c.setColor (Color.WHITE); //sets colour to white

	while (true)
	{
	    try
	    {
		c.setCursor (1, 45); //sets cursor to proper location
		c.fillRect (350, 0, 200, 20); //erases text
		c.setCursor (1, 45); //sets cursor to proper location
		mazeChoice = c.getChar () - '0'; // read user input
		if (mazeChoice < 1 || mazeChoice > 4) //if the user had entered an int that is not a question option
		{
		    throw new ArithmeticException (); //throws an exception
		}
	    }
	    catch (ArithmeticException e)
	    {
		new Message ("You have not entered a menu option. Please enter an int from 1-4."); //causes an error message to pop up if the user entered an in that is not from 1-4
		continue; //continues in loop
	    }
	    break; //exits while loop
	} //closes while loop
    } //closes private mazeQuestion() method


    /*
    gameOfTesting() Local Variables

    Variable Name |  Type         | Function
    ------------------------------------------------
    input         |  BufferedReader | stores the file which will be read from to store the user's name and high scores
    fileName      |  String         | stores the name of the file that this method will be reading from
    output        |  PrintWriter    | stores the file which will be written to to store the user's name and high scores

    Method Description: The public gameOfTesting() method with no return value reads from the file storing high scores and will make any necessary changes including moving the data down.
    Credits: Jonathan made this method
    */
    public void gameOfTesting ()
    {
	Game g = new Game (c); //creates a new Game object using the graphics canvas 'c'
	g.startGame (); //starts the game

	String fileName = "HighScores.txt"; //stores the name of the file that this method will be reading from
	BufferedReader input; //stores the file which will be read from to store the user's name and high scores

	try
	{
	    input = new BufferedReader (new FileReader (fileName)); //reads from high scores file
	    for (int i = 0 ; i < 10 ; i++) //reads the top 10 scores and corresponding names from the file
	    {
		names [i] = input.readLine (); //reads names
		try
		{
		    scores [i] = Integer.parseInt (input.readLine ()); //reads scores
		}
		catch (NumberFormatException e)
		{
		    scores [i] = -1;
		}
	    } //closes for loop
	    input.close (); //closes the input stream
	}
	catch (IOException e)  //handles IOException
	{
	}

	for (int i = 0 ; i < 10 ; i++) //compares the current game level with the existing high scores
	{
	    if (g.gameLevel > scores [i])
	    {
		for (int j = 8 ; j > i ; j--) //moves names and scores to make room for new scores
		{
		    scores [j] = scores [j + 1]; //moves scores
		    names [j] = names [j + 1]; //moves names
		}
		//Insert the new score and name
		scores [i] = g.gameLevel;
		names [i] = name;
		break; //exits the loop
	    }
	} //closes for loop

	// Save the updated high scores back to the file (assuming you want to save them)
	try
	{
	    PrintWriter output = new PrintWriter (new FileWriter ("HighScores.txt")); //stores the file which will be written to to store the user's name and high scores
	    for (int i = 0 ; i < 10 ; i++) //writes the updates names and scores to the file
	    {
		output.println (names [i]); //writes the updated names
		output.println (scores [i]); //writes the updated scores
	    } //closes for loop
	    output.close (); //closes output stream
	}
	catch (IOException e)  //handles IOException
	{
	}
    } //closes public gameOfTesting() method


    /*
      instructions() Local Variables = N/A
      Method Description: The public instructions() method with no return value calls the private title() method to draw the title at the top of the screen. Next, it calls the private flowers() method to draw flowers in the corner
      Credits: Raquel created this method.
    */
    public void instructions ()
    {
	title (); //calls private method that draws title
	c.print ("", 40 - "Instructions".length () / 2);
	c.println ("Instructions\n");

	//Prints Paragraph 1
	c.println ("Hello! Welcome to the Indigenous Culture Journey Program! Designed for users");
	c.println ("aged 10-13, this program educates you on Indigenous culture, beliefs, and");
	c.println ("traditions in Canada. Explore The Creation Story, Tricksters, Transformers,");
	c.println ("Shamans, and Guardian Spirits.");

	//Prints Paragraph 2
	c.println ("\nAfter a brief splash screen, you'll encounter three main sections:");
	c.println ("\nTo Navigate through the main menu: Press (1) in the main menu for the Animated");
	c.println ("Introductions,(2) for Maze of Learning,(3) for Game of Testing, (4) to return to");
	c.println ("Instructions,(5) to view High Scores,(6) to exit the program.");

	//Prints Paragraph 3
	c.println ("\nPlease note that in the mazeOfLearning() the checkpoint will light either green");
	c.println ("(if you got the question correct) or red (if you got the question incorrect)");
	c.println ("after you selected one of the multiple choice answers.");
	c.println ("\nIf you do not plan on exiting the program, we strongly suggest that you select");
	c.println ("(1) to understand the material before continuing to the maze or game.\n");
	pauseProgram (); //calls private method asking for and reading user input
    }


    /*
	 pauseProgram() Local Variables = N/A
	 Method Description: The public pauseProgram() method with no return value prints a message asking for user input then reads it when called.
	 Credits: Raquel created this method.
       */
    private void pauseProgram ()
    {
	c.println ("Press any key to continue:");
	c.getChar (); //reads user input
    }


    /*
      getHighScores() Local Variables

       Variable Name |  Type           | Function
      ------------------------------------------------
       input         |  BufferedReader | stores the file which will store the user's name and high scores
       fileName      |  String         | stores the name of the file that this method will be reading from


       Method Description: The public getHighScores() method with no return value calls the private title() method to draw the title at the top of the screen. Next, it reads from
			   the file containing all high scores set from the game. The method will then print the high scores.
       Credits: Jonathan created this method.
    */
    public void getHighScores ()
    {
	title (); //calls private method that draws title
	String fileName = "HighScores.txt"; //stores the name of the file that this method will be reading from
	BufferedReader input; //stores the file which will store the user's name and high scores

	try
	{
	    input = new BufferedReader (new FileReader (fileName)); //reads from file containing stored names and high scores
	    for (int i = 0 ; i < 10 ; i++) //reads the top 10 scores and corresponding names from the file
	    {
		names [i] = input.readLine (); //reads names
		try
		{
		    scores [i] = Integer.parseInt (input.readLine ()); //reads scores
		}
		catch (NumberFormatException e)
		{
		    scores [i] = -1;
		}
	    } //closes for loop
	    input.close (); //closes output strea,
	}
	catch (IOException e)  //handles IOException
	{

	}

	c.println ("Current High Scores:"); //prints header for current high scores
	for (int i = 0 ; i < 10 ; i++) //goes through the ten names and scores
	{
	    if (scores [i] < 0)
	    {
		break;
	    }
	    c.println ("  " + (i + 1) + ". " + names [i] + " - " + scores [i]); //prints name and correspondimg score
	} //closes for loop
	c.println ("Press any key to continue:"); //asks user for input
	c.getChar (); //reads user input

    } //closes public getHighScores() method


    /*
      flowers() Local Variables

	 Variable Name |  Type           | Function
      ------------------------------------------------
	 flowers       |  BufferedReader | reads from the file where the image of the flowers in stored

      Method Description: The private flowers() method with no return draws flowers in the bottom right corner of the console when called.
      Credits: Raquel created this method.
    */
    private void flowers ()
    {
	try
	{ // imports image
	    BufferedImage flowers = ImageIO.read (new File ("Flowers.png")); //reads from file containing image of flowers
	    c.drawImage (flowers, 270, 155, null); //draws flowers
	}
	catch (IOException e)  //handles IOException
	{
	}
    } //closes private flowers() method


    /*
	 goodBye() Local Variables = N/A
	 Method Description: The public goodBye() method with no return value calls the private title() method to print the title at the top of the screen. Next,
			     prints a goodbye and credits message. Lastly, it calls the private flowers() method to draw flowers in the corner
	 Credits: Jonathan created this method.
    */
    public void goodBye ()
    {
	title (); //calls private method that draws title
	c.println ("Thank you for using this program! Made by Jonathan Ye and Raquel Canto.");
	flowers ();
    } //closes public goodbye() method


    /*
	  classBackground() Local Variables = N/A
	  Method Description: The private classBackground() method with no return draws the classroom background when called.
	  Credits: Raquel created this method.
     */
    private void classBackground ()
    {
	c.setColor (darkBrown); //sets colour to dark brown
	c.fillRect (0, 470, 640, 30);
	c.setColor (peach); //sets colour to peach
	c.fillRect (0, 0, 640, 470); //draws peach background
	c.setColor (oakBrown); //sets colour to oak brown
	c.fillRect (50, 100, 350, 300); //draws chalkboard's wooden back
	c.setColor (brightGreen); //sets colour to bright green
	c.fillRect (60, 110, 330, 260); //draws chalk board
	c.setColor (lightGrey); //sets colour to light grey
	c.fillRect (60, 370, 330, 30); //draws bottom metal part of chalk board
	c.setColor (Color.WHITE); //sets colour to white
	c.fillRect (110, 380, 50, 10); //draws left piece of chalk
	c.fillRect (290, 380, 50, 10); //draws right piece of chalk

	c.setFont (new Font ("Sitka Text", Font.ITALIC, 15)); //sets the font and font size
	//draws text on chalkboard
	c.drawString ("2024-01-08 -  Ms. Canto's Class", 65, 130);
	c.drawString ("TODAY'S ASSIGNMENT", 65, 170);
	c.drawString ("- Research Indigenous Culture", 70, 190);
	c.drawString ("- Creation Story", 90, 210);
	c.drawString ("- Tricksters and Transformers", 90, 230);
	c.drawString ("- Shamans", 90, 250);
	c.drawString ("- Guardian Spirits Quests", 90, 270);
	c.drawString ("- Complete Maze of Learning Assignment", 70, 290);
	c.drawString ("- Get as many points from the Game of", 70, 310);
	c.drawString ("  Testing as possible", 70, 330);
    } //closes private classroomBackground() method


    /*
       nightBackground() Local Variables = N/A
       Method Description: The private nightBackground() method with no return draws the night-time background when called.
       Credits: Raquel and Jonathan created this method.
    */
    private void nightBackground ()
    {
	c.setColor (nightSky); //sets colour to night blue
	c.fillRect (0, 0, 640, 500); //draws night blue background
	c.setColor (darkGreen); //sets colour to dark green
	c.fillRect (0, 350, 640, 75); //draws grass

	c.setColor (dullGreen); //sets colour to dull green

	for (int i = 0 ; i < 50 ; i++)
	{
	    int randomX = (int)Math.floor (Math.random () * 631); // Generates random X between 0 and 635
	    int randomY = (int)Math.floor (Math.random () * (416 - 350) + 350); // Generates random Y between 350 and 420

	    c.fillRect (randomX, randomY, 5, 5);
	}
	c.fillRect (0, 425, 640, 75); //draws text box

	//Draws Stars
	c.setColor (lightYellow); //sets colour to light yellow
	c.fillStar (79, 313, 20, 20);
	c.fillStar (568, 27, 20, 20);
	c.fillStar (76, 270, 20, 20);
	c.fillStar (605, 99, 20, 20);
	c.fillStar (528, 114, 20, 20);
	c.fillStar (22, 94, 20, 20);
	c.fillStar (55, 212, 20, 20);
	c.fillStar (546, 13, 20, 20);
	c.fillStar (584, 16, 20, 20);
	c.fillStar (71, 162, 20, 20);
	c.fillStar (50, 59, 20, 20);
	c.fillStar (157, 114, 20, 20);
	c.fillStar (5, 151, 20, 20);
	c.fillStar (52, 263, 20, 20);
	c.fillStar (34, 207, 20, 20);
	c.fillStar (119, 192, 20, 20);
	c.fillStar (120, 220, 20, 20);
	c.fillStar (471, 50, 20, 20);
	c.fillStar (411, 16, 20, 20);
	c.fillStar (96, 14, 20, 20);
	c.fillStar (157, 51, 20, 20);
	c.fillStar (203, 136, 20, 20);
	c.fillStar (588, 45, 20, 20);
	c.fillStar (281, 130, 20, 20);
	c.fillStar (537, 86, 20, 20);
	c.fillStar (182, 153, 20, 20);
	c.fillStar (228, 144, 20, 20);
	c.fillStar (128, 54, 20, 20);
	c.fillStar (19, 318, 20, 20);
	c.fillStar (387, 49, 20, 20);
    } //closes private nightBackground() method


    /*
	  riverBackground() Local Variables = N/A
	  Method Description: The private riverBackground() method with no return draws the river background when called.
	  Credits: Raquel created this method.
    */
    private void riverBackground ()
    {
	for (int i = 0 ; i <= 350 ; i++) //goes through each y-coordinate to print a differently coloured line creating a gradient effect
	{
	    c.setColor (new Color (i / 2 + 75, 184, 242)); //changes the colour of the background to create a gradient
	    c.drawLine (0, i, 640, i); //draws gradient background line by line
	} //closes for loop

	c.setColor (lightYellow); //sets colour to light yellow
	c.fillArc (250, 250, 240, 240, 0, 180); //draws sun
	c.setColor (darkGreen); //sets colour to dark green
	c.fillRect (0, 350, 640, 75); //draws grass
	c.setColor (dullGreen); //sets colour to dull green
	c.fillRect (0, 425, 640, 75); //draws text box

	//Rocks
	c.setColor (mediumGrey); //sets colour to medium grey
	c.fillOval (25, 225, 150, 150); //draws first rock
	c.setColor (lightGrey); //sets colour to light grey
	c.fillOval (-25, 250, 150, 150); //draws second rock
	c.setColor (darkGrey); //sets colour to dark grey
	c.fillOval (100, 275, 125, 125); //draws third rock
	c.setColor (mediumGrey); //sets colour to medium grey
	c.fillOval (70, 310, 100, 100); //draws fourth rock

	//Water
	c.setColor (brightBlue); //sets colour to bright blue
	c.fillRect (280, 365, 360, 45); //draws water
	c.fillArc (260, 365, 45, 45, 90, 180); //draws end of water

	//Tree
	c.setColor (darkBrown); //sets colour to dark brown
	int treeX1[] = {520, 580, 550}; //sets x-coordinates for tree bark
	int treeY1[] = {350, 350, 200}; //sets y-coordinates for tree bark
	c.fillPolygon (treeX1, treeY1, 3); //draws tree bark
	int treeX2[] = {540, 540, 510, 520, 500}; //sets x-coordinates for left twig
	int treeY2[] = {275, 250, 225, 190, 225}; //sets y-coordinates for left twig
	c.fillPolygon (treeX2, treeY2, 5); //draws left twig
	int treeX3[] = {550, 550, 580, 570, 590, 615}; //sets x-coordinates for top right twig
	int treeY3[] = {270, 240, 205, 180, 200, 180}; //sets y-coordinates for top right wtig
	c.fillPolygon (treeX3, treeY3, 6); //draws top right twig
	int treeX4[] = {550, 550, 590, 580, 600}; //sets x-coordinates for bottom left twig
	int treeY4[] = {340, 300, 270, 240, 270}; //sets y-coordinates for bottom left twig
	c.fillPolygon (treeX4, treeY4, 5); //draws bottom right twig
    } //closes private riverBackground() method


    /*
	  mazeBackground() Local Variables = N/A
	  Method Description: The private mazeBackground() method with no return draws the maze background when called.
	  Credits: Raquel created this method.
       */
    private void mazeBackground ()
    {
	c.setColor (Color.WHITE); //sets colour to white
	c.fillRect (0, 0, 640, 500); //draws white background
	//Draws Maze Borders
	c.setColor (Color.BLACK);
	c.fillRect (20, 20, 600, 10); //draws top border
	c.fillRect (20, 30, 10, 10); //draws the top part of the left border
	c.fillRect (20, 100, 10, 380); //draws the bottom part of the left border
	c.fillRect (20, 470, 600, 10); //draws bottom border
	c.fillRect (610, 20, 10, 140); //draws the top part of the right border
	c.fillRect (610, 220, 10, 260); //draws the bottom part of the right border
	//Draws Maze Box
	c.fillRect (78, 30, 244, 132); //draws black box where the answer correction message will appear
	//Draws Walls Inside Maze
	c.fillRect (78, 218, 4, 194); //draws vertical wall right of first checkpoint
	c.fillRect (78, 218, 184, 4); //draws horizontal wall directly under box
	c.fillRect (198, 158, 4, 62); //draws vertical wall under box
	c.fillRect (138, 278, 4, 192); //draws vertical wall under box
	c.fillRect (138, 278, 64, 4); //draws horiztonal wall under box
	c.fillRect (198, 278, 4, 138); //draws vertical wall under box
	c.fillRect (258, 218, 4, 198); //draws vertical wall under box
	c.fillRect (318, 160, 4, 62); //draws vertical wall under box
	c.fillRect (318, 288, 4, 182); //draws vertical wall under box
	c.fillRect (378, 78, 4, 334); //draws vertical wall to the right of the box
	c.fillRect (318, 158, 64, 4); //draws horizontal wall to the right of the box
	c.fillRect (438, 428, 4, 42); //draws vertical wall
	c.fillRect (378, 358, 64, 4); //draws horizontal wall
	c.fillRect (498, 358, 4, 114); //draws vertical wall
	c.fillRect (558, 298, 4, 124); //draws vertical wall
	c.fillRect (498, 298, 114, 4); //draws horizontal wall
	c.fillRect (498, 158, 4, 144); //draws vertical wall
	c.fillRect (438, 158, 64, 4); //draws horizontal wall
	c.fillRect (438, 78, 4, 84); //draws vertical wall
	c.fillRect (498, 28, 4, 74); //draws vertical wall
	c.fillRect (558, 88, 4, 134); //draws vertical wall
	c.fillRect (558, 156, 54, 4); //draws horizontal wall
	c.fillRect (378, 218, 64, 4); //draws horizontal wall
	c.fillRect (438, 218, 4, 64); //draws vertical wall
    } //closes private mazeBackground()


    /*
    Main method for program that calls everything.

    variable    type                        description
    icj         IndigenousCultureJourney    Creates instance of class

    Credits: Jonathan
    */
    public static void main (String[] args)
    {
	IndigenousCultureJourney icj = new IndigenousCultureJourney (); //creates an instance of the IndigenousCultureJourney class
	icj.splashScreen (); //displays the splash screen
	icj.askData (); //asks the user for input (e.g., name or pseudonym)

	while (icj.menuChoice != 6) //while user decides not to exit
	{
	    icj.mainMenu (); //displays menu options
	    if (icj.menuChoice == 1) //if user selects one in main menu
	    {
		icj.animatedIntroduction (); //animated introduction
	    }
	    else if (icj.menuChoice == 2) //if user selects two in main menu
	    {
		icj.mazeOfLearning (); //maze of learning
	    }
	    else if (icj.menuChoice == 3) //if user selects three in main menu
	    {
		icj.gameOfTesting (); //game of testing
	    }
	    else if (icj.menuChoice == 4) //if user selects four in main menu
	    {
		icj.instructions (); //instructions
	    }
	    else if (icj.menuChoice == 5) //if user selects five in main menu
	    {
		icj.getHighScores (); //high scores screen
	    }
	} //closes while loop
	icj.goodBye (); //goodbye screen and credits
    } //closes main method
} //closes IndigenousCultureJourney class









